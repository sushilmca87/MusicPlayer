//
//  SongModel.swift
//  Music
//
//  Created by SushilKumar on 21/01/18.
//  Copyright © 2018 WildTrails. All rights reserved.
//

import Foundation

open class SongModel: BaseModel {

    open var songId: Int?
    open var name: String?
    open var singerName: String?
    open var imageUrl: String?
    open var songUrl: String?
    open var songDownloadUrl: String?
    open var localDownloadUrl: String?
    open var isFavorite: Bool = false
    open var moreInfo: String?
    open var updatedTimeStamp: String?
    open var downloadState: DownloadState = .download

    override init() {
    }
    
    init(songDict: Dictionary<String, AnyObject>) {
        
        if let _timeStamp = songDict["TimeSpan"] as? String {
            self.updatedTimeStamp = _timeStamp //2018-01-14T20:57:40.11
        }
        
        if let _id = songDict["SongId"] as? Int {
            self.songId = _id
        }
        
        if let _name = songDict["SongName"] as? String {
            self.name = _name
        }
        
        if let _singerName = songDict["SingerName"] as? String {
            self.singerName = _singerName
        }
        
        if let _imageUrl = songDict["ImageUrl"] as? String {
            self.imageUrl = _imageUrl.addingPercentEncoding(withAllowedCharacters: CharacterSet.urlQueryAllowed)
        }
        
        if let _songUrl = songDict["SongUrl"] as? String {
            self.songUrl = _songUrl.addingPercentEncoding(withAllowedCharacters: CharacterSet.urlQueryAllowed)
        }
        
        if let _songDownloadUrl = songDict["SongDownloadUrl"] as? String {
            self.songDownloadUrl = _songDownloadUrl.addingPercentEncoding(withAllowedCharacters: CharacterSet.urlQueryAllowed)
        }
        
        if let _moreInfo = songDict["MoreInfo"] as? String {
            self.moreInfo = _moreInfo
        }
    }
    
    init(_ coreDataModel: Song) {
        self.name = coreDataModel.name!
        self.songId = Int(coreDataModel.songId)
        self.singerName = coreDataModel.singerName!
        self.imageUrl = coreDataModel.imageUrl
        self.songUrl = coreDataModel.songUrl
        self.songDownloadUrl = coreDataModel.songDownloadUrl
        self.localDownloadUrl = coreDataModel.localDownloadUrl
        self.isFavorite = coreDataModel.isFavorite
    }
}

