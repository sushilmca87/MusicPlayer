//
//  SongCollectionViewCell.swift
//  Music
//
//  Created by SushilKumar on 21/01/18.
//  Copyright © 2018 WildTrails. All rights reserved.
//

import UIKit
import SDWebImage

class SongCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var imageView: UIImageView!
    @IBOutlet weak var playImageView: UIImageView!
    @IBOutlet weak var songNameLabel: UILabel!
    
    func configure(song: Song) {
        self.songNameLabel.text = song.name?.capitalized
        self.playImageView.image = #imageLiteral(resourceName: "play-icon")
        
        if let imageUrl = song.imageUrl {
            imageView.sd_setIndicatorStyle(.gray)
            imageView.sd_showActivityIndicatorView()
            imageView.contentMode = .scaleAspectFill

            if let url = URL(string: imageUrl) {
            let placeholder = UIImage(named: "song_placeholder")
            imageView.sd_setImage(with: url, placeholderImage: placeholder, options: [.retryFailed], completed: nil)
           }
        }
    }
    
    func showTune() {
        playImageView.loadGif(name: "tune")
    }
    
    func showDefault() {
        self.playImageView.image = #imageLiteral(resourceName: "play-icon")
    }
}
