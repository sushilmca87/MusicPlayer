//
//  BaseModel.swift
//  Music
//
//  Created by SushilKumar on 21/01/18.
//  Copyright © 2018 WildTrails. All rights reserved.
//

import Foundation

open class BaseModel: NSObject {

    override init() {
    }
}
