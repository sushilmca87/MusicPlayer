//
//  Utils.swift
//  Music
//
//  Created by SushilKumar on 21/01/18.
//  Copyright © 2018 WildTrails. All rights reserved.
//

import Foundation
import SVProgressHUD
import SDWebImage
import SwiftMessages

open class Utils {
    
    static func showProgressIndicator() {
        SVProgressHUD.setDefaultMaskType(.clear)
        SVProgressHUD.setDefaultStyle(.custom)
        SVProgressHUD.setForegroundColor(UIColor.white)
        SVProgressHUD.setBackgroundColor(UIColor.lightGray)
        SVProgressHUD.show()
    }
    
    static func hideProgressIndicator() {
        SVProgressHUD.dismiss()
    }
    
    static func showStatusMessage(title: String, message: String) {
        
        let view = MessageView.viewFromNib(layout: .statusLine)
        view.configureTheme(.error)
        view.configureDropShadow()
        view.configureContent(title: title, body: message)
        view.tapHandler = { (view) in
            SwiftMessages.hideAll()
        }
        var config = SwiftMessages.defaultConfig
        config.presentationStyle = .top
        config.presentationContext = .window(windowLevel: UIWindowLevelStatusBar)
        //config.duration = .seconds(seconds: 20)
        config.duration = .forever
        SwiftMessages.show(config: config, view: view)
    }
    
    static func hideStatusMessage() {
        SwiftMessages.hideAll()
    }
    
    static func calculateTime(_ duration:Float) ->(minute:String, second:String){
        // let hour_   = abs(Int(duration)/3600)
        let minute_ = abs(Int((duration/60).truncatingRemainder(dividingBy: 60)))
        let second_ = abs(Int(duration.truncatingRemainder(dividingBy: 60)))
        
        // var hour = hour_ > 9 ? "\(hour_)" : "0\(hour_)"
        let minute = minute_ > 9 ? "\(minute_)" : "0\(minute_)"
        let second = second_ > 9 ? "\(second_)" : "0\(second_)"
        return (minute,second)
    }
    
    static func showAlert(_ title: String?, message: String?, target: UIViewController) {
        let alertController = UIAlertController(title: title, message: message, preferredStyle: .alert)
        let okayAction = UIAlertAction(title: "Okay", style: .cancel) { (action) in }
        alertController.addAction(okayAction)
        target.present(alertController, animated: true, completion: nil)
    }
    
    static func preparePlayList(_ songs: [Song]) -> [String] {
        
        var urls = [String]()
        for song in songs {
            let currentState = DownloadState(rawValue: Int(song.downloadState))
            if currentState == DownloadState.downloaded {
                urls.append(song.localDownloadUrl!)
            } else {
                urls.append(song.songUrl!)
            }
        }
        
        return urls
    }
}
