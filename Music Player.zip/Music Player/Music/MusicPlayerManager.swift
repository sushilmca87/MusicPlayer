//
//  MusicPlayerManager.swift
//  Music
//
//  Created by SushilKumar on 21/01/18.
//  Copyright © 2018 WildTrails. All rights reserved.
//

import Foundation
import AVFoundation
import MediaPlayer

typealias ChangeStateCallBackHandler = (_ audioPlayer: AudioPlayer, _ fromState: AudioPlayerState, _ toState: AudioPlayerState) -> Void
typealias WillStartPlayingCallBackHandler = (_ audioPlayer: AudioPlayer, _ item: AudioItem) -> Void
typealias UpdateProgressionCallBackHandler = (_ audioPlayer: AudioPlayer, _ time: TimeInterval, _ percentageRead: Float) -> Void
typealias DidFindDurationCallBackHandler = (_ audioPlayer: AudioPlayer, _ duration: TimeInterval, _ item: AudioItem) -> Void
typealias UpdateEmptyMetadataCallBackHandler = (_ audioPlayer: AudioPlayer, _ item: AudioItem, _ data: Metadata) -> Void
typealias DidLoadCallBackHandler = (_ audioPlayer: AudioPlayer, _ range: TimeRange, _ item: AudioItem) -> Void

class MusicPlayerManager: NSObject {
    
    var changeStateCallBackHandler: ChangeStateCallBackHandler?
    var willStartPlayingCallBackHandler: WillStartPlayingCallBackHandler?
    var updateProgressionCallBackHandler: UpdateProgressionCallBackHandler?
    var didFindDurationCallBackHandler: DidFindDurationCallBackHandler?
    var updateEmptyMetadataCallBackHandler: UpdateEmptyMetadataCallBackHandler?
    var didLoadCallBackHandler: DidLoadCallBackHandler?
    
    static let shared = MusicPlayerManager()
    
    private var audioPlayer: AudioPlayer!
    private var currentTrackIndex = 0
    private var isShuffleEnabled = false
    private var isRepeateEnabled = false
    
    var currentSongItems = [Song]()
    
    let offlineMessage = "The Internet connection appears to be offline."
    
    private override init() {
        super.init()
    }
    
    open func setUp() {
        audioPlayer = AudioPlayer()
        audioPlayer.delegate = self
        audioPlayer.adjustQualityAutomatically = true
        audioPlayer.retryEventProducer.maximumRetryCount = 10
        audioPlayer.retryEventProducer.retryTimeout = 30
        audioPlayer.preferredBufferDurationBeforePlayback = 0
        //audioPlayer.preferredForwardBufferDuration = 10
        audioPlayer.bufferingStrategy = .playWhenBufferNotEmpty
    }
    
    open func remoteControlReceived(with event: UIEvent) {
        if audioPlayer != nil {
            audioPlayer.remoteControlReceived(with: event)
        }
    }
    
    open func currentSongItem() -> Song? {
        
        guard let currentTrack = audioPlayer.currentItemIndexInQueue else {
            return nil
        }
        
        return self.currentSongItems[currentTrack]
    }
    
    open func playerTrackIndex() -> Int? {
        return audioPlayer.currentItemIndexInQueue
    }
    
    open func updateSongs(_ songsList: [Song]) {
        self.currentSongItems.removeAll()
        self.currentSongItems.append(contentsOf: songsList)
    }
    
    func playList() -> [AudioItem] {
        
        var items = [AudioItem]()
        for songItem in currentSongItems {
            var url = songItem.songUrl!
            let currentState = DownloadState(rawValue: Int(songItem.downloadState))
            if currentState == DownloadState.downloaded {
                url = songItem.localDownloadUrl!
            }
            let item = AudioItem(mediumQualitySoundURL: URL(string: url))!
            items.append(item)
        }
        
        return items
    }
    
    open func play(with playList: [Song], selectedTrack index: Int) {
        
        if audioPlayer.state.isWaitingForConnection {
            Utils.showStatusMessage(title: "Warning", message: offlineMessage)
        } else if audioPlayer.state.isFailed {
            let msg = audioPlayer.state.error.debugDescription
            Utils.showStatusMessage(title: "Warning", message: msg)
        }
        
        self.updateSongs(playList)
        let info = playList[index]
        print("Song Id =\(info.songId) \n ImageURL    \(info.imageUrl) \n songURL = \(info.songUrl)")
        audioPlayer.play(items: self.playList(), startAtIndex: index)
    }
    
    open func playeImediatly() {
        audioPlayer.play(items: self.playList(), startAtIndex: 0)
    }
    
    open func shuffleEnabled() -> Bool{
        return isShuffleEnabled
    }
    
    open func repeateEnabled() -> Bool{
        return isRepeateEnabled
    }
    
    open func isPlaying() -> Bool{
        return self.audioPlayer.state.isPlaying
    }
    
    open func isPaused() -> Bool {
        return self.audioPlayer.state.isPaused
    }
    
    open func isBuffering() -> Bool {
        return self.audioPlayer.state.isBuffering
    }
    
    open func isStopped() -> Bool {
        return self.audioPlayer.state.isStopped
    }
    
    open func isWaitingForConnection() -> Bool {
         return self.audioPlayer.state.isWaitingForConnection
    }
    
    open func isFailed() -> Bool {
        return self.audioPlayer.state.isFailed
    }
    
    open func hasNext() -> Bool {
        return self.audioPlayer.hasNext
    }
    
    open func hasPrevious() -> Bool {
        return self.audioPlayer.hasPrevious
    }
    
    open func currentTrackDuration() -> Float {
        return Float(self.audioPlayer.currentItemDuration ?? 0)
    }
    
    open func currentTrackProgressDuration() -> Float {
        return Float(self.audioPlayer.currentItemProgression ?? 0)
    }
    
    open func bufferingProgress() -> Float {
        
        guard let currentLastRange = audioPlayer.currentItemLoadedRange?.latest else {
            return 0
        }
        
        let bufferingPercentage = Float(Double(currentLastRange) / Double(audioPlayer.currentItemDuration ?? 0))
        
        return bufferingPercentage
    }
    
    open func  plyerState() -> AudioPlayerState {
        return audioPlayer.state
    }
    
    open func shouldShowTune() -> Bool {
        
        let state = audioPlayer.state
        var flag: Bool = false
        switch state {
            case .buffering, .playing:
                flag = true
            case .paused, .stopped, .failed, .waitingForConnection:
                flag = false
        }
        
        return flag
    }
    
    
    //Player Controls
    
    open func pauseAction() {
        audioPlayer.pause()
    }
    
    open func resumeAction() {
        audioPlayer.resume()
    }
    
    open func stopAction() {
        audioPlayer.stop()
    }
    
    open func nextAction() {
        if MKStoreKit.shared().isUserHasPurchase(){
            audioPlayer.forwordItem()
        }else {
            if  self.playerTrackIndex()! < Int(MAX_PLAY) {
                audioPlayer.forwordItem()
            }else{
               print("user has not purchased this item")
            }
        }
    }
    
    open func previousAction() {
        audioPlayer.backwordItem()
    }
    
    open func shuffleAction() {
        
        if !isShuffleEnabled {
            isShuffleEnabled = true
        } else {
            isShuffleEnabled = false
        }
        
        self.updatePlayerMode()
    }
    
    open func repeatAction() {
        
        if !isRepeateEnabled {
            isRepeateEnabled = true
        } else {
            isRepeateEnabled = false
        }
        
        self.updatePlayerMode()
    }
    
    func updatePlayerMode() {
        
        if isRepeateEnabled && isShuffleEnabled {
            audioPlayer.mode = [.shuffle, .repeat]
        } else if isRepeateEnabled {
            audioPlayer.mode = [.repeat]
        } else if isShuffleEnabled {
            audioPlayer.mode = [.shuffle]
        } else {
            audioPlayer.mode = [.normal]
        }
    }
    
    open func seek(_ time: Float) {
         audioPlayer.seek(to: TimeInterval(time))
    }
}


extension  MusicPlayerManager : AudioPlayerDelegate {
    
    func audioPlayer(_ audioPlayer: AudioPlayer, didChangeStateFrom from: AudioPlayerState, to state: AudioPlayerState) {
        self.changeStateCallBackHandler?(audioPlayer, from, state)
        
        if state.isFailed || state.isWaitingForConnection {
            var alertMessage = offlineMessage
            alertMessage = state.isFailed ? state.error!.localizedDescription : alertMessage
            Utils.showStatusMessage(title: "Warning", message: alertMessage)
        } else {
            Utils.hideStatusMessage()
        }
    }
    
    func audioPlayer(_ audioPlayer: AudioPlayer, willStartPlaying item: AudioItem) {
        self.willStartPlayingCallBackHandler?(audioPlayer, item)
    }
    
    func audioPlayer(_ audioPlayer: AudioPlayer, didUpdateProgressionTo time: TimeInterval, percentageRead: Float) {
        self.updateProgressionCallBackHandler?(audioPlayer, time, percentageRead)
    }
    
    func audioPlayer(_ audioPlayer: AudioPlayer, didFindDuration duration: TimeInterval, for item: AudioItem) {
        self.didFindDurationCallBackHandler?(audioPlayer, duration,  item)
    }
    
    func audioPlayer(_ audioPlayer: AudioPlayer, didUpdateEmptyMetadataOn item: AudioItem, withData data: Metadata) {
        self.updateEmptyMetadataCallBackHandler?(audioPlayer, item,  data)
    }
    
    func audioPlayer(_ audioPlayer: AudioPlayer, didLoad range: TimeRange, for item: AudioItem) {
        self.didLoadCallBackHandler?(audioPlayer, range, item)
    }
}
