//
//  BaseViewController.swift
//  AKSwiftSlideMenu
//
//  Created by SushilKumar on 21/09/15.
//  Copyright (c) 2015 Kode. All rights reserved.
//

import UIKit

enum Filter: Int {
    case none = -1
    case serverSongs = 0
    case myMusic = 1
    case onlineFav = 2
    case offlineFav = 3
}


protocol FilterViewDelegate {
    func didSelectedFilter(_ filterType: Filter)
}

class BaseViewController: UIViewController, SlideMenuDelegate {
    
    open var filterDelegate: FilterViewDelegate?
    open var selectedFilter: Filter = .none
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func slideMenuItemSelectedAtIndex(_ index: Int) {
        
        self.navigationItem.rightBarButtonItem?.isEnabled = true

        if index == -1 {
            return
        }
        
        self.filterDelegate?.didSelectedFilter(Filter.init(rawValue: index)!)
    }
    
    func addSlideMenuButton(){
        let btnShowMenu = UIButton(type: UIButtonType.system)
       // btnShowMenu.setImage(self.defaultMenuImage(), for: UIControlState())
        btnShowMenu.setImage(UIImage(named: "menu"), for: UIControlState())
        btnShowMenu.frame = CGRect(x: 0, y: 0, width: 30, height: 30)
        btnShowMenu.addTarget(self, action: #selector(BaseViewController.onSlideMenuButtonPressed(_:)), for: UIControlEvents.touchUpInside)
        let customBarItem = UIBarButtonItem(customView: btnShowMenu)
        self.navigationItem.leftBarButtonItem = customBarItem;
    }
    
    @objc func onSlideMenuButtonPressed(_ sender : UIButton) {
        
        if (sender.tag == 10) {
            
            // To Hide Menu If it already there
            self.slideMenuItemSelectedAtIndex(-1);

            sender.tag = 0;
            
            let viewMenuBack : UIView = view.subviews.last!
            viewMenuBack.backgroundColor = UIColor.clear
            let btnCloseMenuOverlay = viewMenuBack.viewWithTag(51) as! UIButton
            UIView.animate(withDuration: 0.2, animations: { () -> Void in
                 btnCloseMenuOverlay.alpha = 0.0
                var frameMenu : CGRect = viewMenuBack.frame
                frameMenu.origin.x = -1 * UIScreen.main.bounds.size.width
                viewMenuBack.frame = frameMenu
                viewMenuBack.layoutIfNeeded()
                }, completion: { (finished) -> Void in
                    viewMenuBack.removeFromSuperview()
            })
            
            return
        }
        
        self.navigationItem.rightBarButtonItem?.isEnabled = false
        sender.isEnabled = false
        sender.tag = 10
        
        let menuVC : MenuViewController = self.storyboard!.instantiateViewController(withIdentifier: "MenuViewController") as! MenuViewController
        menuVC.btnMenu = sender
        menuVC.delegate = self
        menuVC.activeFilter = selectedFilter
        self.view.addSubview(menuVC.view)
        self.addChildViewController(menuVC)
        menuVC.view.layoutIfNeeded()
        
        menuVC.view.frame = CGRect(x: 0 - UIScreen.main.bounds.size.width, y: 0, width: UIScreen.main.bounds.size.width, height: UIScreen.main.bounds.size.height);
        
        menuVC.btnCloseMenuOverlay.alpha = 0.0
        menuVC.btnCloseMenuOverlay.tag = 51
        UIView.animate(withDuration: 0.2, animations: {
            menuVC.view.frame=CGRect(x: 0, y: 0, width: UIScreen.main.bounds.size.width, height: UIScreen.main.bounds.size.height);
            sender.isEnabled = true
        }) { (finish) in
            UIView.animate(withDuration: 0.05, animations: {
                menuVC.btnCloseMenuOverlay.alpha = 0.42
            })
        }
        
    }
}
