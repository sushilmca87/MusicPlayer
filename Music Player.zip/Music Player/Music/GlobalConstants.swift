//
//  GlobalConstants.swift
//  Music
//
//  Created by SushilKumar on 21/01/18.
//  Copyright © 2018 WildTrails. All rights reserved.
//

import Foundation

struct Color {
    static let megnta = UIColor(red: 214.0/255.0, green: 17.0/255.0, blue: 116.0/255.0, alpha: 1.0)
    static let menumBlue = UIColor(red: 0/255.0, green: 151/255.0, blue: 215/255.0, alpha: 1.0)
    static let lightYellow = UIColor(red: 242/255.0, green: 200/255.0, blue: 96/255.0, alpha: 1.0)
    static let menumRed = UIColor(red: 230/255.0, green: 80/255.0, blue: 72/255.0, alpha: 1.0)
    static let lighterGray = UIColor(red: 225/255.0, green: 225/255.0, blue: 225/255.0, alpha: 1.0)
    static let navigation = UIColor(red: 18.0/255.0, green: 18.0/255.0, blue: 18.0/255.0, alpha: 1.0)
}

struct ScreenSize {
    static let width = UIScreen.main.bounds.size.width
    static let height = UIScreen.main.bounds.size.height
    static let maxLength = max(width, height)
    static let minLength = min(width, height)
}
