//
//  ReachablityCustome.swift
//  Music
//
//  Created by SushilKumar Singh on 3/17/18.
//  Copyright © 2018 WildTrails. All rights reserved.
//

import UIKit

@objc class ReachablityCustome: NSObject {
    var reachbility:Reachability = Reachability()
 @objc func isInternetConnectionReachable()-> Bool {
        if reachbility.isReachable(){
            return true;
        }else{
            return false;
        }
    }

}
