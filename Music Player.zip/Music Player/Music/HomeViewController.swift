//
//  HomeViewController.swift
//  Music
//
//  Created by SushilKumar on 21/01/18.
//  Copyright © 2018 WildTrails. All rights reserved.
//

import UIKit
import AudioPlayerManager
import MediaPlayer

class HomeViewController: BaseViewController {

    @IBOutlet weak var musicCollectionView: UICollectionView!
    @IBOutlet weak var currentSongImage: UIImageView!
    @IBOutlet weak var currentSongNameLabel: MarqueeLabel!
    @IBOutlet weak var playPauseButton: UIButton!
    @IBOutlet weak var bufferingActivityIndicator: UIActivityIndicatorView!
    @IBOutlet var menuBarButton: UIBarButtonItem!
    @IBOutlet var searchBarButton: UIBarButtonItem!
    
    var purchaseView:PurchaseView!
        
    lazy var searchBar: UISearchBar = {
        let _searchBar = UISearchBar()
        _searchBar.delegate = self
        _searchBar.placeholder = "Search"
        _searchBar.tintColor = UIColor.white
        _searchBar.keyboardAppearance = .dark
        _searchBar.barStyle = .black
        for subView in _searchBar.subviews {
            for subSubView in subView.subviews {
                if subSubView.conforms(to: UITextInputTraits.self) {
                    let textField = subSubView as! UITextField
                    textField.backgroundColor = UIColor.darkGray
                    textField.textColor = UIColor.white
                    break
                }
            }
        }
        
        return _searchBar
    }()

    private var dataSource = Array<Song>()
    private var searchResult = Array<Song>()
    private var currentTrackIndex: Int?
    private var isSearchActive = false
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        self.addSlideMenuButton()
        self.filterDelegate = self
        
        currentSongNameLabel.text = "--"
        currentSongNameLabel.type = .continuous
        currentSongNameLabel.speed = .duration(15.0)
        currentSongNameLabel.fadeLength = 10.0
        currentSongNameLabel.trailingBuffer = 30.0
        currentSongNameLabel.labelWillBeginScroll()
        
        self.bufferingActivityIndicator.alpha = 0
        
        self.configureCallBack()
        
        self.fetchSongs()
        
        self.addPurchaseView()
        self.navigationItem.title = "Server Song"
        
        currentSongImage.contentMode = .scaleAspectFill

    }
    func addPurchaseView(){
        purchaseView = PurchaseView(frame: self.view.bounds)
        
        self.purchaseView.frame = CGRect(x: 0, y: UIScreen.main.bounds.size.height, width: UIScreen.main.bounds.size.width, height: UIScreen.main.bounds.size.height)
        self.purchaseView.autoresizingMask = [.flexibleWidth,.flexibleHeight]
        UIApplication.shared.keyWindow?.rootViewController?.view.addSubview(purchaseView)
       self.view.bringSubview(toFront:  self.purchaseView)

    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        NotificationCenter.default.addObserver(self, selector: #selector(self.appDidBecomeActive), name: NSNotification.Name.UIApplicationDidBecomeActive, object: nil)
    }
    
    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)
        NotificationCenter.default.removeObserver(self)
    }
    
    @objc func appDidBecomeActive() {
        //self.updatePlayerButtonState()
    }
    
    func configureNavigationBar(_ isSearch: Bool) {
        if isSearch {
            self.navigationItem.leftBarButtonItem = nil
            self.navigationItem.rightBarButtonItem = nil
            self.navigationItem.titleView = self.searchBar
            self.searchBar.becomeFirstResponder()
        } else {
            self.navigationItem.leftBarButtonItem = menuBarButton
            self.navigationItem.rightBarButtonItem = searchBarButton
            self.navigationItem.titleView = nil
            self.addSlideMenuButton()
        }
    }
    
    func configureCallBack() {
        
        MusicPlayerManager.shared.updateProgressionCallBackHandler = nil
        MusicPlayerManager.shared.didFindDurationCallBackHandler = nil
        MusicPlayerManager.shared.updateEmptyMetadataCallBackHandler = nil
        MusicPlayerManager.shared.didLoadCallBackHandler = nil
        
        MusicPlayerManager.shared.changeStateCallBackHandler = { (audioPlayer: AudioPlayer, fromState: AudioPlayerState, toState: AudioPlayerState) in
            self.playerStateDidChange(toState)
            
            if let trackIndex = audioPlayer.currentItemIndexInQueue {
                self.updateTrackTune(trackIndex)
            } else {
                self.musicCollectionView.reloadData()
            }
        }
        
        MusicPlayerManager.shared.willStartPlayingCallBackHandler = { (audioPlayer: AudioPlayer, item: AudioItem) in
            if let nextIndex = audioPlayer.currentItemIndexInQueue {
                self.updateTrackUI(nextIndex)
                self.showTrackTune(nextIndex, true)
            }
        }
    }
    
    // DATA
    func fetchSongs() {
        Utils.showProgressIndicator()
        ServiceManager.shared.fetchSongs { (finish, error) in
            DispatchQueue.main.async { [weak self] in
                Utils.hideProgressIndicator()
                if error == nil {
                    self?.updateUI()
                    self?.playPauseButton.isEnabled = true
                } else {
                    let localDBSongs = ServiceManager.shared.getSongs()
                    if localDBSongs.count > 0 {
                        self?.updateUI()
                        self?.musicCollectionView.backgroundView = nil
                        self?.playPauseButton.isEnabled = true
                    } else {
                        //Error View
                        self?.displayFilterMessageView(error!.localizedDescription, hideRetry: false)
                        self?.playPauseButton.isEnabled = false
                    }
                }
            }
        }
    }
    
    // UI
    func updateUI() {
        let songs = ServiceManager.shared.getSongs()
        self.dataSource.removeAll()
        self.dataSource.append(contentsOf: songs)
        self.selectedFilter = .serverSongs
        self.currentTrackIndex = 0
        self.updateSongInfo(0)
        self.musicCollectionView.reloadData()
    }
    
    func playerStateDidChange(_ state: AudioPlayerState) {
        
        UIView.animate(withDuration: 0.3, animations: { () -> Void in
            self.bufferingActivityIndicator.alpha = state == .buffering ? 1 : 0
            self.playPauseButton.alpha = state == .buffering ? 0 : 1
            self.playPauseButton.isEnabled = state == .buffering ? false : true
        })
        
        var flag: Bool = false
        switch state {
        case .buffering, .playing:
            flag = true
        case .paused, .stopped, .failed, .waitingForConnection:
            flag = false
        }
        
        playPauseButton.isSelected = flag
    }
    
    func updateSongInfo(_ trackIndex: Int) {
        
        var track: Song? = nil
        
        let count = self.isSearchActive ? searchResult.count :  dataSource.count
        if trackIndex > count {
            track = MusicPlayerManager.shared.currentSongItem()
        } else if trackIndex < count {
            track = self.isSearchActive ? searchResult[trackIndex] :  dataSource[trackIndex]
        } else {
            return
        }
        
        let trackTitle = track!.name!
        self.currentSongNameLabel.text = (trackTitle + "          " + trackTitle + "          " + trackTitle + "          " + trackTitle + "          " + trackTitle).capitalized
        
        //Configure carousel
        if let imageUrl = track!.imageUrl {
            currentSongImage.sd_setIndicatorStyle(.gray)
            currentSongImage.sd_setShowActivityIndicatorView(true)
            if  let url = URL(string: imageUrl) {
            currentSongImage.sd_setImage(with: url, placeholderImage: UIImage(named: "music-placeholder"), options: [.retryFailed], completed: nil)
            }
        }
    }
    
    
    func updateTrackUI(_ trackIndex: Int) {
    
        if currentTrackIndex == nil {
            return
        }
        
        currentTrackIndex = trackIndex
        
        self.updateSongInfo(trackIndex)
    }
    
    func showTrackTune(_ targetCellIndex: Int, _ show: Bool) {
        
        let indexPath = IndexPath(row: targetCellIndex, section: 0)
        if let cell = self.musicCollectionView.cellForItem(at: indexPath) as? SongCollectionViewCell {
            if show == true {
                cell.showTune()
            } else {
                cell.showDefault()
            }
        }
    }
    
    func updateTrackTune(_ playerTrackIndex: Int) {
        
        let shouldShowTune = MusicPlayerManager.shared.shouldShowTune()
        if self.currentTrackIndex == playerTrackIndex {
            self.showTrackTune(playerTrackIndex, shouldShowTune)
        } else {
            self.showTrackTune(self.currentTrackIndex ?? 0, false)
            self.showTrackTune(playerTrackIndex, shouldShowTune)
        }
    }
    
    func displayFilterMessageView(_ message: String, hideRetry: Bool) {
        let errorView = ErrorMessageView.loadNib(ErrorMessageView.self)
        errorView.configure(message, hideRetry: hideRetry)
        
        if hideRetry == false {
            errorView.retryHandler = { (sender) in
               self.fetchSongs()
            }
        }
        
        self.musicCollectionView.backgroundView = errorView
    }
    
    //MAR:- Button Actions
    
    @IBAction func menuButtonClicked() {
       //To DO Later
    }
    
    @IBAction func searchButtonClicked() {
       self.configureNavigationBar(true)
    }
    
    @IBAction func playPauseButtonClicked() {
        
        if MusicPlayerManager.shared.isPlaying()  {
            MusicPlayerManager.shared.pauseAction()
        } else if MusicPlayerManager.shared.isPaused() {
            MusicPlayerManager.shared.resumeAction()
        } else {
            
            guard let itemItndex = self.currentTrackIndex else {
                return
            }
            
            MusicPlayerManager.shared.play(with: self.dataSource, selectedTrack: itemItndex)
        }
    }
    
    //MARK:- Show Details
    @IBAction func showSongDetails(sender: AnyObject) {
        
        var list = MusicPlayerManager.shared.currentSongItems
        var targetIndex = MusicPlayerManager.shared.playerTrackIndex()
        
        if list.count <= 0 {
            list =  self.dataSource
            targetIndex = self.currentTrackIndex
        }
        
        guard  list.count > 0 else {
            return
        }
        
        let songDetailNavigation = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "SongDetailsNavigationController") as! UINavigationController
        let detailVC = songDetailNavigation.topViewController as! SongDetailsViewController
        
        detailVC.songs = list
        detailVC.currentTrackIndex = targetIndex
        detailVC.backCompletionHandler = { (trackIndex) in
            self.didSelectedFilter(self.selectedFilter)
            self.playerStateDidChange(MusicPlayerManager.shared.plyerState())
            self.configureCallBack()
            self.updateTrackUI(trackIndex)
            self.updateTrackTune(trackIndex)
        }
        
        songDetailNavigation.modalTransitionStyle = .coverVertical
        self.present(songDetailNavigation, animated: true) {
            let currentIndex = IndexPath(row: targetIndex!, section: 0)
            if  let cell = self.musicCollectionView.cellForItem(at: currentIndex) as? SongCollectionViewCell {
                cell.showDefault()
            }
        }
    }
}

extension HomeViewController: UICollectionViewDataSource {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        let count = self.isSearchActive ? searchResult.count:  dataSource.count
        print("count   total song count ==\(count)")
        return count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "SongCollectionViewCell", for: indexPath) as! SongCollectionViewCell
        
        let song = self.isSearchActive ? searchResult[indexPath.row] :  dataSource[indexPath.row]
        cell.configure(song: song)
        
        if let playerSongItem = MusicPlayerManager.shared.currentSongItem() {
            if song.songId == playerSongItem.songId {
                if MusicPlayerManager.shared.shouldShowTune() {
                    cell.showTune()
                } else {
                    cell.showDefault()
                }
            } else {
                cell.showDefault()
            }
        } else {
            cell.showDefault()
        }

        return cell
    }
}

extension HomeViewController: UICollectionViewDelegateFlowLayout {
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        let width  = (collectionView.bounds.size.width / 3.0 ) - 1
        let height  = width //- 22.0
        
        return CGSize(width: width, height: height)
    }
}

extension HomeViewController: UICollectionViewDelegate {
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        collectionView.deselectItem(at: indexPath, animated: true)
        self.checkUserAllotoAccess(indexPath: indexPath as NSIndexPath)
        searchBar.resignFirstResponder()
    }
    func playSong(indexPath:NSIndexPath){
        let index = currentTrackIndex != nil ? currentTrackIndex! : indexPath.row
        self.showTrackTune(index, false)
        currentTrackIndex = indexPath.row
        self.updateTrackUI(currentTrackIndex!)
        let songs = self.isSearchActive ? searchResult :  dataSource
        MusicPlayerManager.shared.stopAction()
        MusicPlayerManager.shared.play(with: songs, selectedTrack: currentTrackIndex!)
    }
    func checkUserAllotoAccess(indexPath:NSIndexPath){
        if indexPath.row < 10 {
            self.playSong(indexPath: indexPath)
            return;
        }
        let userPurchaseInfo = MKStoreKit.shared().isProductPurchaseAndNotExpire()
        switch userPurchaseInfo {
        case USER_IS_NEW:
            if indexPath.row < 10 {
                self.playSong(indexPath: indexPath)
            }else{
                self.showInAppPurchaseView()
            }
            print("user is new trying to as gest");
            break
        case USER_HAS_PURCHASED_BUT_NOT_EXPIRE:
            
            print("product is not expire and user is allreday buy this Product");
            // checking in case user has set date old of phone and trying to access againg from locally then  need to purchase is valid or not
            
            if MKStoreKit.shared().isUserHasPurchase(){
                self.playSong(indexPath: indexPath)
            }else{
                self.showInAppPurchaseView()
            }
            break
        case USER_HAS_PURCHASED_BUT_EXPIRE:
            self.showInAppPurchaseView()
            print("need to show purchase pop view")
            break;
        default:
            print("not found any item ")
            break
        }
    }
    func showInAppPurchaseView(){
        purchaseView.setPrice()
        purchaseView.crossBtn.alpha = 0.0
        purchaseView.crossBtn.isUserInteractionEnabled = false;
        UIView.animate(withDuration: 0.5, animations: {
        }) { (resul) in
            self.purchaseView.frame = CGRect(x: 0, y: 0, width: UIScreen.main.bounds.size.width, height: UIScreen.main.bounds.size.height)
            self.perform(#selector(self.enableCrossBtn), with: nil, afterDelay: 4.0);
        }
    }
   @objc func enableCrossBtn(){
        purchaseView.crossBtn.alpha = 1.0
        purchaseView.crossBtn.isUserInteractionEnabled = true;
    }
}

extension HomeViewController: UISearchBarDelegate {
    
    func searchBarCancelButtonClicked(_ searchBar: UISearchBar) {
        searchBar.showsCancelButton = false
        searchBar.text = ""
        searchBar.resignFirstResponder()
        searchResult.removeAll()
        isSearchActive = false
        self.configureNavigationBar(false)
        self.musicCollectionView.reloadData()
    }
    
    func searchBarTextDidBeginEditing(_ searchBar: UISearchBar) {
        searchBar.showsCancelButton = true
        searchResult.append(contentsOf: self.dataSource)
        isSearchActive = true
        musicCollectionView.reloadData()
    }
    
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
        self.searchBar.resignFirstResponder()
    }
    
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        
        let result = self.dataSource.filter { (song) -> Bool in
            if song.name!.contains(searchText) {
                return true
            }
            return false
        }
        self.searchResult.removeAll()
        self.searchResult.append(contentsOf: result)
        
        if result.count <= 0 {
            self.displayFilterMessageView("No Result !!", hideRetry: true)
        } else {
            musicCollectionView.backgroundView = nil
        }
        
        self.musicCollectionView.reloadData()
    }
}

extension HomeViewController: FilterViewDelegate {
    
    func didSelectedFilter(_ filterType: Filter) {
        
        var result: [Song]!
        var resultMessage = ""
        if filterType == .serverSongs {
            result = ServiceManager.shared.getSongs()
            resultMessage = "No Server Songs Available"
            self.selectedFilter = .serverSongs
            self.navigationItem.title = "Server Song"
        } else if filterType == .myMusic {
            result = ServiceManager.shared.getMyMusicSongs()
            resultMessage = "No My Music Songs Available"
            self.selectedFilter = .myMusic
            self.navigationItem.title = "My Music"
        } else if filterType == .onlineFav {
            result = ServiceManager.shared.getOnlineFavoriteSongs()
            resultMessage = "No Online Favorite Songs Available"
            self.selectedFilter = .onlineFav
            self.navigationItem.title = "Favorite Online"

        }else if filterType == .offlineFav {
            result = ServiceManager.shared.getOfflineFavoriteSongs()
            resultMessage = "No Offline Favorite Songs Available"
            self.selectedFilter = .offlineFav
            self.navigationItem.title = "Favorite Offline"
        }
        
        self.dataSource.removeAll()
        self.dataSource.append(contentsOf: result)
        
        if result.count <= 0 {
            self.displayFilterMessageView(resultMessage, hideRetry: true)
            self.searchBarButton.isEnabled = false
            self.currentTrackIndex = nil
        } else {
            musicCollectionView.backgroundView = nil
            self.searchBarButton.isEnabled = true
            self.currentTrackIndex = 0
        }

        self.musicCollectionView.reloadData()
    }
}
