//
//  ErrorMessageView.swift
//  Music
//
//  Created by SushilKumar on 28/01/18.
//  Copyright © 2018 WildTrails. All rights reserved.
//

import UIKit

class ErrorMessageView: UIView {

    @IBOutlet weak var iconImage: UIImageView!
    @IBOutlet weak var retryButton: UIButton!
    @IBOutlet weak var messageLabel: UILabel!
    
    var message: String = "" {
        didSet {
            messageLabel.text = message
        }
    }
    
    open var retryHandler: ((_ sender: Any) -> Void)?
    
    @IBAction func retryButtonClicked() {
        retryHandler?(self)
    }
    
    open func configure(_ message: String, hideRetry: Bool) {
         messageLabel.text = message
        self.retryButton.isHidden = hideRetry
    }
    
}
