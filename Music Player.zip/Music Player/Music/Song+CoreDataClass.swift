//
//  Song+CoreDataClass.swift
//  Music
//
//  Created by SushilKumar on 03/02/18.
//  Copyright © 2018 WildTrails. All rights reserved.
//
//

import Foundation
import CoreData

@objc(Song)
public class Song: NSManagedObject {

    convenience init(context: NSManagedObjectContext, songModel: SongModel) {
        
        guard let entity = NSEntityDescription.entity(forEntityName: String(describing: Song.self), in: context) else {
            fatalError("Unable to get entity named \(String(describing: Song.self))")
        }
        
        self.init(entity: entity, insertInto: context)
        
        let sId = Float(songModel.songId!)
        self.songId = Int16(sId)
        self.name = songModel.name
        self.singerName = songModel.singerName
        self.imageUrl = songModel.imageUrl
        self.songUrl = songModel.songUrl
        self.songDownloadUrl = songModel.songDownloadUrl
        self.isFavorite = songModel.isFavorite
        self.localDownloadUrl = songModel.localDownloadUrl
        self.moreInfo = songModel.moreInfo
        let state = Float(songModel.downloadState.rawValue)
        self.downloadState = Int16(state)
    }
    
    override init(entity: NSEntityDescription, insertInto context: NSManagedObjectContext?) {
        super.init(entity: entity, insertInto: context)
    }
}
