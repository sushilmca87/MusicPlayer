//
//  ServiceManager.swift
//  Music
//
//  Created by SushilKumar on 21/01/18.
//  Copyright © 2018 WildTrails. All rights reserved.
//

import Foundation

typealias CompletionHandler = (_ songs: Array<Song>?, _ error: Error?) -> Void
typealias SuccessHandler = (_ result: Bool, _ error: Error?) -> Void

class ServiceManager: NSObject {
    static var shared = ServiceManager()
    
    var requestHandler: CompletionHandler?
    
    override init() {
        super.init()
    }
    
    func fetchSongs(_ completion: @escaping SuccessHandler) {
        Webservice.fetchSongs { (data, error) in
            if error == nil {
                let responsDict = data as! Dictionary<String, AnyObject>
                let results = responsDict["result"] as! Array<Dictionary<String, AnyObject>>
                self.sync(with: results, requestHandler: completion)
            } else {
                 completion(false, error)
            }
        }
    }
    
    func sync(with jsonArray: Array<Dictionary<String, AnyObject>>, requestHandler: SuccessHandler?) {
        
        for itemDict in jsonArray {
            let aSongModel = SongModel.init(songDict: itemDict)
            let predicate = NSPredicate(format: "songId = %d", aSongModel.songId!)
            let oldSong = DataManager.fetchObject(entity: Song.self, predicate: predicate, sortDescriptors: nil, context: DataManager.mainContext)
            if oldSong == nil {
                _ = Song.init(context: DataManager.mainContext, songModel: aSongModel)
            }
        }
        
        if DataManager.mainContext.hasChanges {
            DataManager.persist(synchronously: false, completion: { (error) in
                if (error == nil) {
                    requestHandler?(true, nil)
                } else {
                    requestHandler?(false, error)
                }
            })
        } else {
            requestHandler?(true, nil)
        }
    }
    
    
    func getSong(_ songId: Int) -> Song?  {
        let predicate = NSPredicate(format: "songId = %d", songId)
        let resultSongModel = DataManager.fetchObject(entity: Song.self, predicate: predicate, sortDescriptors: nil, context: DataManager.mainContext)
        
        return resultSongModel
    }
    
    func getSongs() -> [Song] {
        let allOldSongs = DataManager.fetchObjects(entity: Song.self, predicate: nil, sortDescriptors: nil, context: DataManager.mainContext)
        
        return allOldSongs
    }
    
    func getMyMusicSongs() -> [Song] {
        let predicate = NSPredicate(format: "downloadState = %d", DownloadState.downloaded.rawValue)
        let results = DataManager.fetchObjects(entity: Song.self, predicate: predicate, sortDescriptors: nil, context: DataManager.mainContext)
        
        return results
    }
    
    func getOnlineFavoriteSongs() -> [Song] {
        let predicate = NSPredicate(format: "isFavorite = %@", true as CVarArg )
        let results = DataManager.fetchObjects(entity: Song.self, predicate: predicate, sortDescriptors: nil, context: DataManager.mainContext)
        
        return results
    }
    
    func getOfflineFavoriteSongs() -> [Song] {
        let predicate = NSPredicate(format: "downloadState = %d and isFavorite = %@", DownloadState.downloaded.rawValue , true as CVarArg )
        let results = DataManager.fetchObjects(entity: Song.self, predicate: predicate, sortDescriptors: nil, context: DataManager.mainContext)
        
        return results
    }
    
    func updateRecord(_ record: SongModel) {
        let result  = ServiceManager.shared.getSong(record.songId!)
        if (result != nil) {
           _ =  Song.init(context: DataManager.mainContext, songModel: record)
        }
        DataManager.persist(synchronously: false, completion: nil)
    }
}
