//
//  Song+CoreDataProperties.swift
//  Music
//
//  Created by SushilKumar on 03/02/18.
//  Copyright © 2018 WildTrails. All rights reserved.
//
//

import Foundation
import CoreData

public enum DownloadState: Int {
    case download
    case downloading
    case downloaded
}

extension Song {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<Song> {
        return NSFetchRequest<Song>(entityName: "Song")
    }

    @NSManaged public var imageUrl: String?
    @NSManaged public var isFavorite: Bool
    @NSManaged public var name: String?
    @NSManaged public var localDownloadUrl: String?
    @NSManaged public var singerName: String?
    @NSManaged public var songDownloadUrl: String?
    @NSManaged public var songId: Int16
    @NSManaged public var songUrl: String?
    @NSManaged public var timeStamp: NSDate?
    @NSManaged public var moreInfo: String?
    @NSManaged public var downloadState: Int16
}
