//
//  Webservice.swift
//  Music
//
//  Created by SushilKumar on 21/01/18.
//  Copyright © 2018 WildTrails. All rights reserved.
//
import UIKit
import Alamofire

typealias ResponseHandler = (AnyObject? , Error?) -> Void

class Webservice {

    private class func fetchData(method:HTTPMethod, url:String, params:[String:AnyObject]? = nil, completion: @escaping ResponseHandler) {
        Alamofire.request(URL(string: url)!, method: method, parameters: params).validate().responseJSON { (response) -> Void in
            if response.result.isSuccess && response.result.error == nil {
                completion(response.result.value as AnyObject, nil)
            } else {
                completion(nil, response.result.error)
            }
        }
    }
    
    func donloadData() {
        //Alamofire.download(<#T##urlRequest: URLRequestConvertible##URLRequestConvertible#>, to: <#T##DownloadRequest.DownloadFileDestination?##DownloadRequest.DownloadFileDestination?##(URL, HTTPURLResponse) -> (destinationURL: URL, options: DownloadRequest.DownloadOptions)#>)
    }
    
    private class func fetchDataWithPost(url:String, params:[String:AnyObject]? = nil, completion: @escaping ResponseHandler) {
        self.fetchData(method: .post, url: url, completion: completion)
    }
    
    private  class func fetchDataWithGet(url:String, completion: @escaping ResponseHandler) {
        self.fetchData(method: .get, url: url, completion: completion)
    }
    
    //MARK:- API
    public class func fetchSongs(completion: @escaping ResponseHandler) {
        let url = "http://iapptechnology.com/kishorkumar1/api/SongsDetails/GetSongsDetails"
        Webservice.fetchDataWithGet(url: url, completion: completion)
    }
}
