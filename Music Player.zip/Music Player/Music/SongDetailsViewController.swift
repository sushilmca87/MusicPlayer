//
//  SongDetailsViewController.swift
//  Music
//
//  Created by SushilKumar on 21/01/18.
//  Copyright © 2018 WildTrails. All rights reserved.
//

import UIKit
import Alamofire
import SDWebImage

class SongDetailsViewController: UIViewController {

    @IBOutlet weak var musicCoverFlow: iCarousel!
    @IBOutlet weak var likeButton: UIButton!
    @IBOutlet weak var downloadButton: UIButton!
    @IBOutlet weak var musicSlider: UISlider!
    @IBOutlet weak var bufferingProgressView: UIProgressView!
    @IBOutlet weak var bufferingActivityIndicator: UIActivityIndicatorView!
    @IBOutlet weak var playPauseButton: UIButton!
    @IBOutlet weak var rewindButton: UIButton!
    @IBOutlet weak var forwardButton: UIButton!
    @IBOutlet weak var shuffleButton: UIButton!
    @IBOutlet weak var repeatButton: UIButton!
    @IBOutlet weak var songNameLabel: MarqueeLabel!
    @IBOutlet weak var songSingerNameLabel: MarqueeLabel!
    @IBOutlet weak var currentDurationLabel: UILabel!
    @IBOutlet weak var totalDurationLabel: UILabel!
    @IBOutlet weak var downloadLabel: UILabel!
    
    var purchaseView:PurchaseView!


    var backCompletionHandler:((_ currentTrackIndex: Int) -> Void)?
    
    var songs: [Song]!
    var currentTrackIndex: Int!
    private var playList:[String]!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        self.title = "Music"
        
        let backBarButton = UIBarButtonItem(image: #imageLiteral(resourceName: "back"), style: .plain, target: self, action: #selector(SongDetailsViewController.backButtonClicked))
        backBarButton.tintColor = UIColor.white
        self.navigationItem.leftBarButtonItem = backBarButton
        
        self.resetUI()
        
        //Coverflow
        musicCoverFlow.type = .linear
        musicCoverFlow.delegate = self
        musicCoverFlow.dataSource = self
        musicCoverFlow.isPagingEnabled = true
        musicCoverFlow.currentItemIndex = currentTrackIndex

        songNameLabel.type = .continuous
        songNameLabel.speed = .duration(15.0)
        songNameLabel.fadeLength = 10.0
        songNameLabel.trailingBuffer = 30.0
        songSingerNameLabel.type = .continuous
        songSingerNameLabel.speed = .duration(15.0)
        songSingerNameLabel.fadeLength = 10.0
        songSingerNameLabel.trailingBuffer = 30.0
        songSingerNameLabel.labelWillBeginScroll()
        
        let thumbImage = UIImage(named: "music_slider_circle")
        musicSlider.setThumbImage(thumbImage, for: .normal)
        musicSlider.setThumbImage(thumbImage, for: .highlighted)
        
        let currentTrackProgress = MusicPlayerManager.shared.currentTrackProgressDuration()
        let trackDuration = MusicPlayerManager.shared.currentTrackDuration()
        self.updateCurrentTrackDuration(TimeInterval(currentTrackProgress))
        self.updateTrackDuration(TimeInterval(trackDuration))
        let buffer = MusicPlayerManager.shared.bufferingProgress()
        self.updateBufferingProgress(buffer)
        self.musicSlider.value = currentTrackProgress
        self.musicSlider.maximumValue = trackDuration
        self.shuffleButton.isSelected = MusicPlayerManager.shared.shuffleEnabled()
        self.repeatButton.isSelected = MusicPlayerManager.shared.repeateEnabled()

        self.updatePlayerControl()
        self.playerStateDidChange(MusicPlayerManager.shared.plyerState())

        self.updateUI(currentTrackIndex)
        self.configureCallBack()
        
        self.addPurchaseView()
    }
    func addPurchaseView(){
        purchaseView = PurchaseView(frame: self.view.bounds)
        
        self.purchaseView.frame = CGRect(x: 0, y: UIScreen.main.bounds.size.height, width: UIScreen.main.bounds.size.width, height: UIScreen.main.bounds.size.height)
        self.purchaseView.autoresizingMask = [.flexibleWidth,.flexibleHeight]
        UIApplication.shared.keyWindow?.addSubview(purchaseView)
        self.view.bringSubview(toFront:  self.purchaseView)
        
    }
    
    @objc func backButtonClicked() {
        self.dismiss(animated: true) {
            self.backCompletionHandler?(self.currentTrackIndex)
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
        self.updateItemView(self.currentTrackIndex)
    }
    
    @objc func appDidBecomeActive() {
        
    }
    
    func updateCurrentTrackDuration(_ duration: TimeInterval) {
        let minutes = Int(duration / 60)
        let seconds = Int(duration) - minutes * 60
        self.currentDurationLabel.text = String(format: "%02d", minutes) + ":" + String(format: "%02d", seconds)
    }
    
    func updateTrackDuration(_ duration: TimeInterval) {
        let minutes = Int(duration / 60)
        let seconds = Int(duration) - minutes * 60
        self.totalDurationLabel.text = String(format: "%02d", minutes) + ":" + String(format: "%02d", seconds)
    }
    
    func updateBufferingProgress(_ progress: Float) {
        self.bufferingProgressView.setProgress(progress, animated: true)
    }
    
    func configureCallBack() {
        
        MusicPlayerManager.shared.changeStateCallBackHandler = { (audioPlayer: AudioPlayer, fromState: AudioPlayerState, toState: AudioPlayerState) in
            
            self.playerStateDidChange(toState)
            
            if audioPlayer.state.isPlaying || audioPlayer.state.isBuffering {
                self.showPlayingTune(audioPlayer.currentItemIndexInQueue ?? self.currentTrackIndex )
            } else {
                self.showDefaul(audioPlayer.currentItemIndexInQueue ?? self.currentTrackIndex)
            }
        }
        
        MusicPlayerManager.shared.willStartPlayingCallBackHandler = { (audioPlayer: AudioPlayer, item: AudioItem) in
            self.resetUI()
            self.updateUI(audioPlayer.currentItemIndexInQueue ?? self.currentTrackIndex)
            self.updatePlayerControl()
        }
        
        MusicPlayerManager.shared.updateProgressionCallBackHandler = { (audioPlayer: AudioPlayer, time: TimeInterval, percentageRead: Float) in
            self.musicSlider.value = Float(time)
            self.updateCurrentTrackDuration(time)
        }
        
        MusicPlayerManager.shared.didFindDurationCallBackHandler = { (audioPlayer: AudioPlayer, duration: TimeInterval, item: AudioItem)  in
            self.updateTrackDuration(duration)
            self.musicSlider.maximumValue = Float(duration)
        }
        
        MusicPlayerManager.shared.didLoadCallBackHandler = { (audioPlayer: AudioPlayer, range: TimeRange, item: AudioItem) in
            let bufferingPercentage = Float(Double(range.latest) / Double(audioPlayer.currentItemDuration!))
            self.updateBufferingProgress(bufferingPercentage)
        }
    }
    
   
    @IBAction func downloadButtonClicked() {
        
        if (Utiity.isMonthlyOrYearlySubscribe()  == false) {
            self.showInAppPurchaseView()
        }
        
        let currentTrack = songs[musicCoverFlow.currentItemIndex]
        
        currentTrack.downloadState = Int16(DownloadState.downloading.rawValue)
        DataManager.persist(synchronously: false)
        
        self.downloadLabel.text = "Downloading..."
        
        let destination: DownloadRequest.DownloadFileDestination = { _, _ in
            var documentsURL = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
            documentsURL.appendPathComponent(currentTrack.songDownloadUrl!)
            return (documentsURL, [.removePreviousFile, .createIntermediateDirectories])
        }

        Alamofire.download(currentTrack.songDownloadUrl!, to: destination).response { response in
            DispatchQueue.main.async { [weak self] in
                if response.error == nil {
                    if response.destinationURL != nil {
                        currentTrack.localDownloadUrl = response.destinationURL?.absoluteString
                        currentTrack.downloadState = Int16(DownloadState.downloaded.rawValue)
                        DataManager.persist(synchronously: false)
                        self?.downloadLabel.text = "Downloaded"
                    }
                } else {
                    self?.downloadLabel.text = "Download"
                    currentTrack.downloadState = Int16(DownloadState.download.rawValue)
                    DataManager.persist(synchronously: false)
                    Utils.showAlert("Unable to download", message:  response.error?.localizedDescription, target: self!)
                }
            }
        }
    }
    
    @IBAction func shareButtonClicked() {
        
        var items =  [Any] ()
        let currenTrack = self.songs[currentTrackIndex]
        items.append(currenTrack.name!)
        items.append(currenTrack.singerName!)
        //items.append(currenTrack.songUrl!)
        
        let shareActivityController  = UIActivityViewController(activityItems: items, applicationActivities: nil)
        let excludeActivities = [UIActivityType.print,UIActivityType.assignToContact,UIActivityType.saveToCameraRoll,UIActivityType.addToReadingList,UIActivityType.airDrop]
        shareActivityController.excludedActivityTypes = excludeActivities
        self.present(shareActivityController, animated: true, completion: nil)
    }
    
    @IBAction func infoButtonClicked() {
        
        let currenTrack = self.songs[currentTrackIndex]

        let message = "Song Title: \(currenTrack.name!)\nSinger Name: \(currenTrack.singerName!)\nMoer Info: \(currenTrack.moreInfo!)"
        let alertController = UIAlertController(title: "Song Info", message: message, preferredStyle: .alert)
        let okayAction = UIAlertAction(title: "Okay", style: .cancel) { (action) in }
        alertController.addAction(okayAction)
        
        self.present(alertController, animated: true, completion: nil)
    }
    
    @IBAction func likeButtonClicked() {
        likeButton.isSelected = !likeButton.isSelected
        let currentSong = self.songs[musicCoverFlow.currentItemIndex]
        currentSong.isFavorite = likeButton.isSelected
        DataManager.persist(synchronously: false)
    }
    
    //Mark:- Update UI

    func resetUI() {
        bufferingProgressView.setProgress(0, animated: false)
        musicSlider.setValue(0, animated: false)
        currentDurationLabel.text = String(format: "%02d", 0) + ":" + String(format: "%02d", 0)
        totalDurationLabel.text = String(format: "%02d", 0) + ":" + String(format: "%02d", 0)
    }
    
    func updateUI(_ trackIndex: Int) {
        self.showDefaul(currentTrackIndex)
        currentTrackIndex = trackIndex
        self.showPlayingTune(currentTrackIndex)
        musicCoverFlow.currentItemIndex = trackIndex
        self.updateSongInfo(trackIndex)
    }
    
    func updateSongInfo(_ trackIndex: Int) {
        let track = self.songs[trackIndex]

        let trackTitle = track.name!
        let artistName = track.singerName!
        self.songNameLabel.text = (trackTitle + "          " + trackTitle + "          " + trackTitle + "          " + trackTitle + "          " + trackTitle).capitalized
        self.songSingerNameLabel.text = (artistName + "          " + artistName + "          " + artistName + "          " + artistName + "          " + artistName).capitalized
        
        let currentState = DownloadState(rawValue: Int(track.downloadState))
        if currentState == DownloadState.downloaded {
            self.downloadLabel.text = "Downloaded"
        } else if currentState == DownloadState.downloading {
            self.downloadLabel.text = "Downloading..."
        } else {
            self.downloadLabel.text = "Download"
        }
        
        self.likeButton.isSelected = track.isFavorite
    }
    
    func updatePlayerControl() {
        self.rewindButton?.isEnabled = MusicPlayerManager.shared.hasPrevious()
        self.forwardButton?.isEnabled = MusicPlayerManager.shared.hasNext()
    }
    
    
    //MARK:- Player Controle
    
    @IBAction func musicSliderValueChanged(sender: UISlider) {
        MusicPlayerManager.shared.seek(self.musicSlider.value)
    }
    
    @IBAction func shuffleButtonClicked() {
        MusicPlayerManager.shared.shuffleAction()
        shuffleButton.isSelected =  MusicPlayerManager.shared.shuffleEnabled()
    }
    
    @IBAction func repeatButtonClicked() {
        MusicPlayerManager.shared.repeatAction()
        repeatButton.isSelected =  MusicPlayerManager.shared.repeateEnabled()
    }
    
    @IBAction func previousButtonClicked() {
        MusicPlayerManager.shared.previousAction()
        self.updatePlayerControl()
    }
    
    @IBAction func nextButtonClicked() {
        if self.isAbleToPlay() == true {
             MusicPlayerManager.shared.nextAction()
            self.updatePlayerControl()
        }else{
            print("*** showInAppPurchaseView   *(*****")
            self.showInAppPurchaseView()
        }
    }
    func isAbleToPlay() -> Bool {
        let index = MusicPlayerManager.shared.playerTrackIndex()!
        print("index   \(index)")
        var isNeedToPlay = false;
        if index < MAX_PLAY {
            isNeedToPlay = true;
            return isNeedToPlay;
        }
        let userPurchaseInfo = MKStoreKit.shared().isProductPurchaseAndNotExpire()
        switch userPurchaseInfo {
        case USER_IS_NEW:
            if index < MAX_PLAY {
                isNeedToPlay = true;
            }else{
                isNeedToPlay = false;
            }
            print("user is new trying to as gest");
            break
        case USER_HAS_PURCHASED_BUT_NOT_EXPIRE:
            
            print("product is not expire and user is allreday buy this Product");
            // checking in case user has set date old of phone and trying to access againg from locally then  need to purchase is valid or not
            
            if MKStoreKit.shared().isUserHasPurchase(){
                isNeedToPlay = true;
            }else{
                isNeedToPlay = false;
            }
            break
        case USER_HAS_PURCHASED_BUT_EXPIRE:
            isNeedToPlay = false;
            print("need to show purchase pop view")
            break;
        default:
            print("not found any item ")
            break
        }
        return isNeedToPlay;
    }
    func showInAppPurchaseView(){
        purchaseView.setPrice()
        purchaseView.crossBtn.alpha = 0.0
        purchaseView.crossBtn.isUserInteractionEnabled = false;
        UIView.animate(withDuration: 0.5, animations: {
        }) { (resul) in
            self.purchaseView.frame = CGRect(x: 0, y: 0, width: UIScreen.main.bounds.size.width, height: UIScreen.main.bounds.size.height)
            print("frame self.purchaseView    =\(self.purchaseView)")
            self.perform(#selector(self.enableCrossBtn), with: nil, afterDelay: 4.0);
        }
    }
    @objc func enableCrossBtn(){
        purchaseView.crossBtn.alpha = 1.0
        purchaseView.crossBtn.isUserInteractionEnabled = true;
    }
    
    @IBAction func playPauseButtonClicked() {
        
        if MusicPlayerManager.shared.isPlaying()  {
            MusicPlayerManager.shared.pauseAction()
        } else if MusicPlayerManager.shared.isPaused() {
            MusicPlayerManager.shared.resumeAction()
        } else {
            self.playSelectedTrack(musicCoverFlow.currentItemIndex)
        }
    }
    
    func playSelectedTrack(_ trackIndex: Int) {
        MusicPlayerManager.shared.stopAction()
        MusicPlayerManager.shared.play(with: self.songs, selectedTrack: trackIndex)
        self.updateSongInfo(trackIndex)
    }
    
    func playerStateDidChange(_ state: AudioPlayerState) {
        
        UIView.animate(withDuration: 0.3, animations: { () -> Void in
            self.bufferingActivityIndicator.alpha = state == .buffering ? 1 : 0
            self.playPauseButton.alpha = state == .buffering ? 0 : 1
            self.playPauseButton.isEnabled = state == .buffering ? false : true
        })
        
        var flag: Bool = false
        switch state {
            case .buffering, .playing:
                flag = true
            case .paused, .stopped, .failed, .waitingForConnection:
               flag = false
        }
        
        playPauseButton.isSelected = flag
    }
}

extension SongDetailsViewController: iCarouselDataSource {
    
    @objc func playTuneTapped() {
        if currentTrackIndex == musicCoverFlow.currentItemIndex {
            if MusicPlayerManager.shared.isPlaying()  {
                MusicPlayerManager.shared.pauseAction()
            } else if MusicPlayerManager.shared.isPaused() {
                MusicPlayerManager.shared.resumeAction()
            } else {
                self.playSelectedTrack(musicCoverFlow.currentItemIndex)
            }
        } else {
            self.playSelectedTrack(musicCoverFlow.currentItemIndex)
        }
    }
    
    func numberOfItems(in carousel: iCarousel) -> Int {
        return songs.count
    }
    
    func carousel(_ carousel: iCarousel, viewForItemAt index: Int, reusing view: UIView?) -> UIView {
        
        var itemView: UIImageView
        let placeholder = UIImage(named: "song_placeholder")
        var customeView:UIView
        
        //create new view if no view is available for recycling
        if (view == nil) {
            let w =  UIScreen.main.bounds.size.width - 10
            let h =  UIScreen.main.bounds.height - 100
            
            customeView = UIView(frame: CGRect(x: 0, y: 0, width: w, height: h))
            print("customeView   \(customeView.frame) and \(musicCoverFlow.frame)")
            itemView = UIImageView(frame:customeView.bounds)
            itemView.clipsToBounds = true
            itemView.image = placeholder
            itemView.contentMode = .scaleAspectFill
            itemView.layer.cornerRadius = 5
            itemView.tag = 111;
            customeView.addSubview(itemView)
            customeView.needsUpdateConstraints()
            
            let playIcon = UIImageView(frame: CGRect(x:  w - 40, y: h - 150 , width: 30, height: 30))
            playIcon.backgroundColor = UIColor.init(red: 0, green: 0, blue: 0, alpha: 0.25)
            playIcon.image = #imageLiteral(resourceName: "play-icon")
            playIcon.tag = 151
            playIcon.layer.cornerRadius = playIcon.frame.size.width/2
            playIcon.backgroundColor = UIColor.red
            itemView.addSubview(playIcon)
            itemView.setNeedsDisplay()
            
            playIcon.isUserInteractionEnabled = true
            itemView.isUserInteractionEnabled = true
            let tapGesture = UITapGestureRecognizer(target: self, action: #selector(self.playTuneTapped))
            playIcon.addGestureRecognizer(tapGesture)
            
        } else {
            //get a reference to the label in the recycled view
            customeView = view! ;
        }
        
        
        //Configure carousel
        let currentTrack = songs[index]
        
        //Tune Icon
        if let playerSongItem = MusicPlayerManager.shared.currentSongItem() {
            if currentTrack.songId == playerSongItem.songId {
                if MusicPlayerManager.shared.shouldShowTune() {
                    self.showPlayingTune(index)
                } else {
                    self.showDefaul(index)
                }
            }
        }
        
        //Image
        if let imageUrl = currentTrack.imageUrl {
            itemView = customeView.viewWithTag(111) as! UIImageView
            itemView.sd_setIndicatorStyle(.gray)
            itemView.sd_setShowActivityIndicatorView(true)
            if   let url = URL(string: imageUrl) {
               itemView.sd_setImage(with: url, placeholderImage: placeholder, options: [.retryFailed], completed: nil)
            }else{
                print("image not found imageUrl:\(imageUrl)")
            }
        }
    
        return customeView
    }
    
    func updateItemView(_ index: Int) {
        
        if self.currentTrackIndex == index && MusicPlayerManager.shared.shouldShowTune()  {
            self.showPlayingTune(index)
        } else {
            self.showDefaul(index)
        }
    }
    
    func showPlayingTune(_ trackIndex: Int) {
        if MusicPlayerManager.shared.shouldShowTune() == true , let itemView = musicCoverFlow.itemView(at: trackIndex) {
            let playIcon = itemView.viewWithTag(151) as! UIImageView
            playIcon.backgroundColor = UIColor.clear
            playIcon.layer.cornerRadius = 0
            playIcon.loadGif(name: "tune")
        }
    }
    
    func showDefaul(_ trackIndex: Int) {
        if let itemView = musicCoverFlow.itemView(at: trackIndex) {
            let playIcon = itemView.viewWithTag(151) as! UIImageView
            playIcon.stopAnimating()
            playIcon.backgroundColor = UIColor.init(red: 0, green: 0, blue: 0, alpha: 0.25)
            playIcon.image = nil
            playIcon.image = #imageLiteral(resourceName: "play-icon")
            playIcon.layer.cornerRadius = playIcon.frame.size.width/2
        }
    }
}


extension SongDetailsViewController: iCarouselDelegate {
    
    func carousel(_ carousel: iCarousel, valueFor option: iCarouselOption, withDefault value: CGFloat) -> CGFloat {

        if (option == .spacing){
            return (value * 1.1)
        }
        else  if (option == .wrap){
            return 0
        }

        return value
    }
    
    func carouselCurrentItemIndexDidChange(_ carousel: iCarousel) {
        self.updateSongInfo(carousel.currentItemIndex)
        self.updateItemView(carousel.currentItemIndex)
    }
    
    func carousel(_ carousel: iCarousel, didSelectItemAt index: Int) {
        self.updateSongInfo(index)
    }
}
