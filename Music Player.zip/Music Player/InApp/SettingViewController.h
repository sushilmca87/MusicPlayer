//
//  SettingViewController.h
//  Shafdfdgf
//
//  Created by SushilKumar on 7/8/15.
//  Copyright (c) 2015 Effone. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "PurchaseView.h"
#import "BaseObjectiveCViewController.h"

@interface SettingViewController : BaseObjectiveCViewController
{
    
}
@property (nonatomic,assign) BOOL isUserAllreadyRemoveAdd;

@end


@interface SettingTableViewCell : UITableViewCell
{
    NSInteger quantityMultiply;
}
@property(nonatomic,strong)UIImageView *cellImage;
@property (nonatomic,strong)UILabel *titleLbleInfo;
@property (nonatomic,strong)UISwitch *mSwitch;



@end
