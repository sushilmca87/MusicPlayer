//
//  Utiity.m
//  SwiftHandBook
//
//  Created by sushil on 29/06/15.
//  Copyright (c) 2015 sushil. All rights reserved.
//
#define CHAPTER_SELECTED @"chapterSelected"
#define ITEM_PURCHASED @"userPurchased"
#define IS_SHIRING @"IsSharing"


#import "Utiity.h"
#import "SampleHeader.h"
#import <Foundation/Foundation.h>
#import <AVFoundation/AVFoundation.h>
#import "MKStoreKit.h"

#define IS_WHITE_TEXT_COLOR "textColor"


@interface Utiity (){
 
    AVAudioPlayer *bakgroundAudioPlayer;
}
@end
@implementation Utiity

+(Utiity*)sharedInstance{
    static Utiity *scoreMapper = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken,^{
    scoreMapper = [[Utiity alloc]init];
    });
    return scoreMapper;
}
-(void)setPurchaseRequest{
    [[MKStoreKit sharedKit] startProductRequest];
    [[NSNotificationCenter defaultCenter] addObserverForName:kMKStoreKitProductsAvailableNotification object:nil queue:[NSOperationQueue mainQueue] usingBlock:^(NSNotification * _Nonnull note) {
        NSLog(@"availableProducts == %@",[[MKStoreKit sharedKit] availableProducts]);
    }];
}
+(UIColor*)getNaviBarColor{
    return[UIColor colorWithRed:18/255.0f green:18/255.0f blue:18/255.0f alpha:1];
}

+(UIColor*)getTextColor
{
    BOOL isWhitetextColor = [[NSUserDefaults standardUserDefaults]boolForKey:@IS_WHITE_TEXT_COLOR];
    UIColor *textColor;
    if(isWhitetextColor)
    {
        textColor = [UIColor whiteColor];
    }
    else
    {
        textColor = [UIColor whiteColor];
        
    }
    return textColor;
}
+(UIColor*)getTextColor12
{
    BOOL isWhitetextColor = [[NSUserDefaults standardUserDefaults]boolForKey:@IS_WHITE_TEXT_COLOR];
    UIColor *textColor;
    if(isWhitetextColor)
    {
        textColor = [UIColor greenColor];
    }
    else
    {
        textColor = [UIColor blackColor];

    }
    return textColor;
}
+(UIColor*)getViewControllerColoerBcakgroundColor{
    return [UIColor colorWithRed:0.95 green:0.95 blue:0.95 alpha:1]; /*#fafafa*///whitesimiler;
}
+(UIColor*)getTableBckgroundColor{
    BOOL isWhitetextColor = [[NSUserDefaults standardUserDefaults]boolForKey:@IS_WHITE_TEXT_COLOR];
    UIColor *textColor;
    if(isWhitetextColor)
    {
       // textColor = [UIColor colorWithRed:0.031 green:0.031 blue:0.031 alpha:1];//black similer
        
        textColor = [UIColor whiteColor]; /*#fafafa*///whitesimiler

    }
    else
    {
        textColor = [UIColor whiteColor]; /*#fafafa*///whitesimiler
        
        
    }
    return textColor;
}
+(UIColor*)getDarkGreenClor{
    return [UIColor colorWithRed:49/255.0f green:143/255.0f blue:0/255.0f alpha:1];
}

+(UIColor*)getBlueColorColor{
    return ([UIColor colorWithRed:25/255.0f green:95/255.0f blue:240/255.0f alpha:1]);
}
+(UIColor*)getOuterCircleClorCombination{
    BOOL isWhitetextColor = [[NSUserDefaults standardUserDefaults]boolForKey:@IS_WHITE_TEXT_COLOR];
    UIColor *textColor;
    if(isWhitetextColor)
    {
        textColor = [UIColor colorWithRed:49/255.0f green:143/255.0f blue:0/255.0f alpha:1]; /*#fafafa*///whitesimiler
    }
    else
    {
        textColor = [UIColor colorWithRed:25/255.0f green:95/255.0f blue:240/255.0f alpha:1];//black similer
        
    }
    return textColor;
}
-(void)playBackgroungAudio
{
    
    if([Utiity getIsBackgroundMusicsEnable])
    {
        if(bakgroundAudioPlayer.isPlaying)
        {
            return;
        }
        
        NSString *filePath = [[NSBundle mainBundle]pathForResource:@"omkaramMusics" ofType:@"mp3"];
        NSURL *url = [NSURL fileURLWithPath:filePath];
        NSError *error;
        bakgroundAudioPlayer = [[AVAudioPlayer alloc] initWithContentsOfURL:url error:&error];
        bakgroundAudioPlayer.numberOfLoops = -1;
        bakgroundAudioPlayer.volume = .7;
        

        
        [bakgroundAudioPlayer play];
    }
}
-(void)stopPlayBckgroundMusicActionByUser
{
    if(bakgroundAudioPlayer)
    {
        [bakgroundAudioPlayer stop];
    }
}







+(NSString*)trailPurchasePrice{
    return [[NSUserDefaults standardUserDefaults] objectForKey:TRAIL_PURCHASE];
}
+(void)setTrailPurchasePrice:(NSString*)price{
    [[NSUserDefaults standardUserDefaults] setObject:price forKey:TRAIL_PURCHASE];
    [[NSUserDefaults standardUserDefaults] synchronize];
}
+(NSString*)monthlyPurchasePrice{
    return [[NSUserDefaults standardUserDefaults] objectForKey:MONTHLY_PURCHASE];
}
+(void)setMonthlyPurchasePrice:(NSString*)price{
    [[NSUserDefaults standardUserDefaults] setObject:price forKey:MONTHLY_PURCHASE];
    [[NSUserDefaults standardUserDefaults] synchronize];
}
+(NSString*)yearlyPurchasePrice{
    return [[NSUserDefaults standardUserDefaults] objectForKey:YEARLY_PURCHASE];
}
+(void)setYearlyPurchasePrice:(NSString*)price{
    [[NSUserDefaults standardUserDefaults] setObject:price forKey:YEARLY_PURCHASE];
    [[NSUserDefaults standardUserDefaults] synchronize];
}
+(void)setMonthlyOrYearlySubscribe:(BOOL) isSubscribe{
    [[NSUserDefaults standardUserDefaults] setBool:isSubscribe forKey:@"MonthlyOrYearlySubscribe"];
}
+(BOOL)isMonthlyOrYearlySubscribe{
    return [[NSUserDefaults standardUserDefaults] boolForKey:@"MonthlyOrYearlySubscribe"];
}





+(BOOL)getIsUserHasPurchasedItemFromAppStore{
    //return [[NSUserDefaults standardUserDefaults] boolForKey:ITEM_PURCHASED];
    return YES;
}
+(void)setIsUserHasPurchasedItemFromAppStore:(BOOL)isPurchase{
    [[NSUserDefaults standardUserDefaults] setBool:isPurchase forKey:ITEM_PURCHASED];
    [[NSUserDefaults standardUserDefaults] synchronize];
}

+(BOOL)getIsBackgroundMusicsEnable{
    return [[NSUserDefaults standardUserDefaults] boolForKey:@"BackgroundMusica"];
    //    return YES;
}
+(void)setgetIsBackgroundMusicsEnable:(BOOL)enable{
    [[NSUserDefaults standardUserDefaults] setBool:enable forKey:@"BackgroundMusica"];
    [[NSUserDefaults standardUserDefaults] synchronize];
}
+(BOOL)getIsDefaultSettingEnable{
    return [[NSUserDefaults standardUserDefaults] boolForKey:@"DefaulteSetting"];
    //    return YES;
}
+(void)setDefaulteSettingEnable:(BOOL)enable{
    [[NSUserDefaults standardUserDefaults] setBool:enable forKey:@"DefaulteSetting"];
    [[NSUserDefaults standardUserDefaults] synchronize];
}




+(void)setUsrerHasShairedThisAppOnFacOrTwitter:(BOOL)isShaire{
    [[NSUserDefaults standardUserDefaults] setBool:isShaire forKey:IS_SHIRING];
    [[NSUserDefaults standardUserDefaults] synchronize];
}
+(BOOL)getUserHasSharedOr_Not{
    //return [[NSUserDefaults standardUserDefaults] boolForKey:IS_SHIRING];
    return YES;
    
}
+(UIColor*)getBgColor
{
    BOOL isWhitetextColor = [[NSUserDefaults standardUserDefaults]boolForKey:@IS_WHITE_TEXT_COLOR];
    UIColor *textColor;
    if(isWhitetextColor)
    {
        textColor = [UIColor colorWithRed:0 green:0 blue:0 alpha:1];// total black color
    }
    else
    {
        textColor = [UIColor whiteColor];//total white color
        
    }
    return textColor;
}
+(UIColor*)getBgCollectionViewTableColor
{
    BOOL isWhitetextColor = [[NSUserDefaults standardUserDefaults]boolForKey:@IS_WHITE_TEXT_COLOR];
    UIColor *textColor;
    if(isWhitetextColor)
    {
        textColor = [UIColor colorWithRed:0 green:0 blue:0 alpha:1];// total black color
    }
    else
    {
        textColor =  [UIColor colorWithRed:0.95 green:0.95 blue:0.95 alpha:1];//total white color
        
    }
    return textColor;
}
+(UIColor*)getWthoutCodeColor12
{
    BOOL isWhitetextColor = [[NSUserDefaults standardUserDefaults]boolForKey:@IS_WHITE_TEXT_COLOR];
    UIColor *textColor;
    if(isWhitetextColor)
    {
        textColor = [UIColor colorWithRed:0.031 green:0.031 blue:0.031 alpha:1];//black similer
    }
    else
    {
        textColor = [UIColor colorWithRed:0.98 green:0.98 blue:0.98 alpha:1]; /*#fafafa*///whitesimiler
        
        
    }
    return textColor;
}
+(UIColor*)getBgCollectionViewTableColor12
{
    BOOL isWhitetextColor = [[NSUserDefaults standardUserDefaults]boolForKey:@IS_WHITE_TEXT_COLOR];
    UIColor *textColor;
    if(isWhitetextColor)
    {
        textColor = [UIColor colorWithRed:0 green:0 blue:0 alpha:1];// total black color
        
//        textColor = [UIColor whiteColor];

    }
    else
    {
        textColor =  [UIColor colorWithRed:0.95 green:0.95 blue:0.95 alpha:1];//total white color
        
//        textColor = [UIColor blueColor];
        
    }
    return textColor;
}
+(UIColor*)getWthoutCodeColor
{
    BOOL isWhitetextColor = [[NSUserDefaults standardUserDefaults]boolForKey:@IS_WHITE_TEXT_COLOR];
    UIColor *textColor;
    if(isWhitetextColor)
    {
        textColor = [UIColor colorWithRed:0.031 green:0.031 blue:0.031 alpha:1];//black similer
    }
    else
    {
        textColor = [UIColor colorWithRed:0.98 green:0.98 blue:0.98 alpha:1]; /*#fafafa*///whitesimiler

        
    }
    return textColor;
}

+(UIColor*)getTextCircleColor{
    return [UIColor colorWithRed:53/255.0f green:135/255.0f blue:39/255.0f alpha:1];
}
+(UIColor*)getBlackTextColor{
    return [UIColor blackColor];
}

+(NSAttributedString*)getColorRangeMutableTextStringWithTheDescription:(UILabel*)textLbl
{
    UIColor *doubleQoutesColor = [UIColor colorWithRed:0.804 green:0.31 blue:0.224 alpha:1]; /*#cd4f39*/
    NSString *codeStr = textLbl.text;
    NSMutableAttributedString *text =[[NSMutableAttributedString alloc]initWithAttributedString: textLbl.attributedText];
    
    // getting range of string only content the string "" double quets
    NSScanner *scanner = [NSScanner scannerWithString:codeStr];
    NSString *tmp;
    while ([scanner isAtEnd] == NO)
    {
        [scanner scanUpToString:@"\"" intoString:NULL];
        [scanner scanString:@"\"" intoString:NULL];
        [scanner scanUpToString:@"\"" intoString:&tmp];
        if ([scanner isAtEnd] == NO)
        {
            if(tmp != nil){
                NSRange substringRange = [codeStr rangeOfString:tmp];
                [text addAttribute:NSForegroundColorAttributeName
                             value:doubleQoutesColor
                             range:NSMakeRange(substringRange.location, substringRange.length)];
            }
        }
        [scanner scanString:@"\"" intoString:NULL];
    }
    [textLbl setAttributedText: text];
    
    
    return textLbl.attributedText;
}

+(NSAttributedString*)getColorRangeMutableTextString:(UITextView*)textLbl
{
    UIColor *keywordColor = [UIColor colorWithRed:0 green:0.498 blue:1 alpha:1]; /*#007fff*/
    UIColor *doubleQoutesColor = [UIColor colorWithRed:0.804 green:0.31 blue:0.224 alpha:1]; /*#cd4f39*/
    
    NSArray *keywordArray = [NSArray arrayWithContentsOfFile:[[NSBundle mainBundle] pathForResource:@"keyword" ofType:@"plist"]];

    NSString *codeStr = textLbl.text;
    NSMutableAttributedString *text =[[NSMutableAttributedString alloc]initWithAttributedString: textLbl.attributedText];
    
    
    for(NSString *rangeWithStr in keywordArray)
    {  [codeStr enumerateSubstringsInRange:NSMakeRange(0, [codeStr length])
                               options:NSStringEnumerationByWords | NSStringEnumerationLocalized
                            usingBlock:^(NSString *substring, NSRange substringRange, NSRange enclosingRange, BOOL *stop) {
                                if ([substring isEqualToString: rangeWithStr])
                                {
                                    [text addAttribute:NSForegroundColorAttributeName
                                                 value:keywordColor
                                                 range:NSMakeRange(substringRange.location, substringRange.length)];
                                }
                                else
                                {
                                    //NSLog(@"substring not matching == %@..",substring);
                                }
                                
                            }];
        
    }
    
    // getting range of string only content the string "" double quets
    NSScanner *scanner = [NSScanner scannerWithString:codeStr];
    NSString *tmp;
    while ([scanner isAtEnd] == NO)
    {
        [scanner scanUpToString:@"\"" intoString:NULL];
        [scanner scanString:@"\"" intoString:NULL];
        [scanner scanUpToString:@"\"" intoString:&tmp];
        if ([scanner isAtEnd] == NO)
        {
            if(tmp != nil){
            NSRange substringRange = [codeStr rangeOfString:tmp];
            [text addAttribute:NSForegroundColorAttributeName
                         value:doubleQoutesColor
                         range:NSMakeRange(substringRange.location, substringRange.length)];
            }
        }
        [scanner scanString:@"\"" intoString:NULL];
    }
    [textLbl setAttributedText: text];


    return textLbl.attributedText;
}
+(UIColor*)getCircleColorWithHighleted
{
    BOOL isWhitetextColor = [[NSUserDefaults standardUserDefaults]boolForKey:@IS_WHITE_TEXT_COLOR];
    UIColor *textColor;
    if(isWhitetextColor)
    {
        textColor = [UIColor colorWithRed:0 green:1 blue:1 alpha:.5];// highleted //littile bit blue color
        
    }
    else
    {
        textColor = [UIColor colorWithRed:0 green:1 blue:1 alpha:1];// highleted //littile bit blue color
        
    }
    return textColor;
}

+(UIColor*)getCircleColor
{
    BOOL isWhitetextColor = [[NSUserDefaults standardUserDefaults]boolForKey:@IS_WHITE_TEXT_COLOR];
    UIColor *textColor;
    if(isWhitetextColor)
    {
        
        textColor = [UIColor colorWithRed:0.188 green:0 blue:0 alpha:1]; /*#300000*/ /*#fafafa*///whitesimiler
        textColor = [UIColor colorWithWhite:.1 alpha:1];
    }
    else
    {
        textColor = [UIColor colorWithRed:0.957 green:0.957 blue:0.957 alpha:1];//gray color
        textColor = [UIColor colorWithWhite:.6 alpha:1];

    }
    return textColor;
}
+(UIColor*)getChapterColor{
  
    BOOL isWhitetextColor = [[NSUserDefaults standardUserDefaults]boolForKey:@IS_WHITE_TEXT_COLOR];
    UIColor *textColor;
    if(isWhitetextColor)
    {
        textColor = [UIColor whiteColor]; /*#300000*/ /*#fafafa*///whitesimiler
    }
    else
    {
        textColor = [UIColor whiteColor];//gray color
    }
    return textColor;
}
+(UIColor*)getAppGreeNColor{
    return [UIColor whiteColor];
   // return [UIColor colorWithRed:49/255.0f green:211/255.0f blue:112/255.0f alpha:1.0f];
   // return [UIColor colorWithRed:0.671 green:0.961 blue:0.749 alpha:1]; /*#2efe2e*/;

}

+(UIColor*)getGreeTextNColor{
    return [UIColor colorWithRed:0.024 green:0.514 blue:0.153 alpha:1];
    // return [UIColor colorWithRed:0.671 green:0.961 blue:0.749 alpha:1]; /*#2efe2e*/;
}
+(void)setSelectedChapterByUser:(NSString*)chapterName
{
    [[NSUserDefaults standardUserDefaults]setObject:chapterName forKey:CHAPTER_SELECTED];
    [[NSUserDefaults standardUserDefaults] synchronize];
}
+(NSString*)getSelectedChapterByUser
{
    NSString *chapter = [[NSUserDefaults standardUserDefaults] objectForKey:CHAPTER_SELECTED];
    return chapter;
}
+(float)getWindowRatio:(CGRect)frame{
    float size;
    if(UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad){
        size = .002325*(frame.size.width);
    }else{
        size =.003125*(frame.size.width);
    }
    return size;
    
}

@end
