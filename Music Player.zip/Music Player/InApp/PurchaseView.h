//
//  PurchaseView.h
//  Colories
//
//  Created by Sushil on 11/7/16.
//  Copyright © 2016 Effone. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PurchaseView : UIView
@property (nonatomic,strong) UIButton *crossBtn;
-(void)setPrice;
@end
