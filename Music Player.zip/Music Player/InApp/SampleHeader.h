//
//  Header.h
//  Music
//
//  Created by SushilKumar Singh on 3/11/18.
//  Copyright © 2018 WildTrails. All rights reserved.
//

#ifndef Header_h
#define Header_h



#define TRAIL_PURCHASE    @"com.iapptechnology.kishoresongTrial"
#define MONTHLY_PURCHASE  @"com.iapptechnology.kishoresongMonthly"
#define YEARLY_PURCHASE   @"com.iapptechnology.kishoresongYearly"


#define MAX_PLAY  10

#define RESTORE_PURCHASE @"A prior purchase transaction could not be found. To restore the purchased product, tap the Remove Ads. Paid customers will NOT be charged again, but the purchase will be restored."
#define PURCHASE_SUCCESSFULL @"Your purchase was successful and Ads is now removed for your enjoyment!"








#endif /* Header_h */
