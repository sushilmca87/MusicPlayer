//
//  IAPHelper.m
//  In App Rage
//
//  Created by sushil.
//  Copyright (c) 2015 sushil. All rights reserved.
//

// 1
#import "IAPHelper.h"
#import <StoreKit/StoreKit.h>
#import "SampleHeader.h"

NSString *const IAPHelperProductPurchasedNotification = @"IAPHelperProductPurchasedNotification";
NSString *const IAPHelperProductPurchasedFailedNotification = @"IAPHelperProductPurchasedFailedNotification";

// 2
@interface IAPHelper () <SKProductsRequestDelegate, SKPaymentTransactionObserver>{
    UIActivityIndicatorView *indecater;
    RequestProductsCompletionHandler _completionHandler;
    SKProductsRequest * _productsRequest;
    
    NSSet * _productIdentifiers;
    NSMutableSet * _purchasedProductIdentifiers;
}
@end

// 3
@implementation IAPHelper
@synthesize delegate;
- (id)initWithProductIdentifiers:(NSSet *)productIdentifiers {
    
    if ((self = [super init])) {
        
        // Store product identifiers
        _productIdentifiers = productIdentifiers;
        
        // Check for previously purchased products
        _purchasedProductIdentifiers = [NSMutableSet set];
        for (NSString * productIdentifier in _productIdentifiers) {
            BOOL productPurchased = [[NSUserDefaults standardUserDefaults] boolForKey:productIdentifier];
            if (productPurchased) {
                [_purchasedProductIdentifiers addObject:productIdentifier];
                NSLog(@"Previously purchased: %@", productIdentifier);
            } else {
                NSLog(@"Not purchased: %@", productIdentifier);
            }
        }
        
        
        [self addActivityIndecater];
        // Add self as transaction observer
        [[SKPaymentQueue defaultQueue] addTransactionObserver:self];
        
    }
    return self;
    
}
-(void)addActivityIndecater{
    
    indecater = [[UIActivityIndicatorView alloc]initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleWhite];
    [indecater setFrame:CGRectMake(0, 0, 80, 80)];
    indecater.center = [[[[UIApplication sharedApplication] delegate] window]center];
    [[[[UIApplication sharedApplication] delegate] window]addSubview:indecater];
    indecater.backgroundColor = [UIColor blackColor];
    indecater.layer.cornerRadius = 8;
    indecater.alpha = .8;
    [indecater stopAnimating];
    //[indecater setHidden:YES];
    
}
-(void)showActivityView{
    [indecater startAnimating];
    [indecater setHidden:NO];
    [[[[UIApplication sharedApplication] delegate] window]setUserInteractionEnabled:NO];
}
-(void)hideActivity{
    [indecater stopAnimating];
    [indecater setHidden:YES];
    [[[[UIApplication sharedApplication] delegate] window]setUserInteractionEnabled:YES];
}
-(void)showAlertAction:(NSString*)message
{
    UIAlertView *loALert = [[UIAlertView alloc]initWithTitle:@"Alert!" message:message delegate:self cancelButtonTitle:nil otherButtonTitles:@"Ok", nil];
    [loALert setTag:1000];
    [loALert show];
}

- (void)requestProductsWithCompletionHandler:(RequestProductsCompletionHandler)completionHandler {
    
    // 1
    _completionHandler = [completionHandler copy];
    // 2
    _productsRequest = [[SKProductsRequest alloc] initWithProductIdentifiers:_productIdentifiers];
    _productsRequest.delegate = self;
    [_productsRequest start];
}

- (BOOL)productPurchased:(NSString *)productIdentifier {
    return [_purchasedProductIdentifiers containsObject:productIdentifier];
}

- (void)buyProduct:(SKProduct *)product {
    [self showActivityView];
    NSLog(@"Buying %@...", product.productIdentifier);
    SKPayment * payment = [SKPayment paymentWithProduct:product];
    [[SKPaymentQueue defaultQueue] addPayment:payment];
}

#pragma mark - SKProductsRequestDelegate

- (void)productsRequest:(SKProductsRequest *)request didReceiveResponse:(SKProductsResponse *)response {
    
    NSLog(@"Loaded list of products...");
    // _productsRequest = nil;
    
    NSArray * skProducts = response.products;
    for (SKProduct * skProduct in skProducts) {
        NSLog(@"Found product: %@ %@ %0.2f  %@",
              skProduct.productIdentifier,
              skProduct.localizedTitle,
              skProduct.price.floatValue,[self getNumberFormated:skProduct]);
    }
    
    _completionHandler(YES, skProducts);
    // _completionHandler = nil;
    
}
-(NSString*)getNumberFormated:(SKProduct*)product{
  
    NSNumberFormatter *formater  = [[NSNumberFormatter alloc]init];
    formater.numberStyle = NSNumberFormatterCurrencyStyle;
    formater.locale = product.priceLocale;
    NSString *str = [formater stringFromNumber:product.price];
    return str;
    
}
- (void)request:(SKRequest *)request didFailWithError:(NSError *)error {
    
    NSLog(@"Failed to load list of products.");
    _productsRequest = nil;
    _completionHandler(NO, nil);
    // _completionHandler = nil;
    // [self showAlertAction:@"Your transaction is getting failed!"];
}

#pragma mark SKPaymentTransactionOBserver

- (void)paymentQueue:(SKPaymentQueue *)queue updatedTransactions:(NSArray *)transactions
{
    for (SKPaymentTransaction * transaction in transactions) {
        switch (transaction.transactionState)
        {
            case SKPaymentTransactionStatePurchased:
                [self completeTransaction:transaction];
                break;
            case SKPaymentTransactionStateFailed:
                [self failedTransaction:transaction];
                break;
            case SKPaymentTransactionStateRestored:
                [self restoreTransaction:transaction];
            default:
                break;
        }
    };
}

- (void)completeTransaction:(SKPaymentTransaction *)transaction {
    NSLog(@"completeTransaction... purchase was successful");
    [self provideContentForProductIdentifier:transaction.payment.productIdentifier];
    [[SKPaymentQueue defaultQueue] finishTransaction:transaction];
    [self showAlertAction:PURCHASE_SUCCESSFULL];
    [self hideActivity];
}

- (void)restoreTransaction:(SKPaymentTransaction *)transaction {
    NSLog(@"restoreTransaction...purchase was restored");
    [self provideContentForProductIdentifier:transaction.originalTransaction.payment.productIdentifier];
    [[SKPaymentQueue defaultQueue] finishTransaction:transaction];
    [self hideActivity];
    [self showAlertAction:@"Successfully restore your purchasees!"];
}

- (void)failedTransaction:(SKPaymentTransaction *)transaction {
    
    NSLog(@"failedTransaction...");
    if (transaction.error.code != SKErrorPaymentCancelled)
    {
        NSLog(@"Transaction error: %@", transaction.error.localizedDescription);
    }
    
    [[SKPaymentQueue defaultQueue] finishTransaction: transaction];
    
    [[NSNotificationCenter defaultCenter] postNotificationName:IAPHelperProductPurchasedFailedNotification object:transaction.error userInfo:nil];
    [self hideActivity];
    [self showAlertAction:@"Could not connect to itunes store."];
    
    
}

- (void)provideContentForProductIdentifier:(NSString *)productIdentifier {
    [_purchasedProductIdentifiers addObject:productIdentifier];
    [[NSUserDefaults standardUserDefaults] setBool:YES forKey:productIdentifier];
    [[NSUserDefaults standardUserDefaults] synchronize];
    [[NSNotificationCenter defaultCenter] postNotificationName:IAPHelperProductPurchasedNotification object:productIdentifier userInfo:nil];
}

- (void)restoreCompletedTransactions {
    [self showActivityView];
    [[SKPaymentQueue defaultQueue] restoreCompletedTransactions];
}





// Called when SKPaymentQueue has finished sending restored transactions.
- (void)paymentQueueRestoreCompletedTransactionsFinished:(SKPaymentQueue *)queue {
    
    NSLog(@"EBPurchase paymentQueueRestoreCompletedTransactionsFinished");
    
    if ([queue.transactions count] == 0) {
        // Queue does not include any transactions, so either user has not yet made a purchase
        // or the user's prior purchase is unavailable, so notify app (and user) accordingly.
        
        NSLog(@"EBPurchase restore queue.transactions count == 0");
        
        // Release the transaction observer since no prior transactions were found.
        [[SKPaymentQueue defaultQueue] removeTransactionObserver:self];
        
        if ([delegate respondsToSelector:@selector(incompleteRestore:)])
            [delegate incompleteRestore:self];
        
        [self hideActivity];
        UIAlertView *restoreAlert = [[UIAlertView alloc] initWithTitle:@"Restore Issue" message:RESTORE_PURCHASE delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
        [restoreAlert show];
        
        
    } else {
        // Queue does contain one or more transactions, so return transaction data.
        // App should provide user with purchased product.
        NSLog(@"EBPurchase restore queue.transactions available");
        
        [self hideActivity];
        
        for(SKPaymentTransaction *transaction in queue.transactions) {
            NSLog(@"EBPurchase restore queue.transactions - transaction data found");
            if ([delegate respondsToSelector:@selector(successfulPurchase:restored:identifier:receipt:)])
                [delegate successfulPurchase:self restored:YES identifier:transaction.payment.productIdentifier receipt:transaction.transactionReceipt];
        }
    }
}

// Called if an error occurred while restoring transactions.
- (void)paymentQueue:(SKPaymentQueue *)queue restoreCompletedTransactionsFailedWithError:(NSError *)error
{
    // Restore was cancelled or an error occurred, so notify user.
    
    NSLog(@"EBPurchase restoreCompletedTransactionsFailedWithError");
    
    
    [self hideActivity];
    NSLog(@"ViewController failedRestore");
    // Restore request failed or was cancelled, so notify the user.
    UIAlertView *failedAlert = [[UIAlertView alloc] initWithTitle:@"Restore Stopped" message:@"Could not connect to itunes store." delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
    [failedAlert show];
    
    if ([delegate respondsToSelector:@selector(failedRestore:error:message:)])
        [delegate failedRestore:self error:error.code message:error.localizedDescription];
}




@end
