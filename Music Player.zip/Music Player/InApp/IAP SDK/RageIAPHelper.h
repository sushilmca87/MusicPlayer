//
//  RageIAPHelper.h
//  In App Rage
//
//  Created by SushilKumar on 9/5/18.
//  Copyright (c) 2012 Razeware LLC. All rights reserved.
//

#import "IAPHelper.h"

@interface RageIAPHelper : IAPHelper

+ (RageIAPHelper *)sharedInstance;

@end
