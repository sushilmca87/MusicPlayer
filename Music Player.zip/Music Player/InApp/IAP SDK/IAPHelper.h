//
//  IAPHelper.h
//  In App Rage
//
//  Created by SushilKumar on 9/5/18.
//  Copyright (c) 2012 Razeware LLC. All rights reserved.
//

#import <StoreKit/StoreKit.h>

UIKIT_EXTERN NSString *const IAPHelperProductPurchasedNotification;
UIKIT_EXTERN NSString *const IAPHelperProductPurchasedFailedNotification;



typedef void (^RequestProductsCompletionHandler)(BOOL success, NSArray * products);
@protocol IAPHelperDelegate;

@interface IAPHelper : NSObject{
}
@property(nonatomic,strong) id<IAPHelperDelegate> delegate;

- (id)initWithProductIdentifiers:(NSSet *)productIdentifiers;
- (void)requestProductsWithCompletionHandler:(RequestProductsCompletionHandler)completionHandler;
- (void)buyProduct:(SKProduct *)product;
- (BOOL)productPurchased:(NSString *)productIdentifier;
- (void)restoreCompletedTransactions;
@end

@protocol IAPHelperDelegate<NSObject>
-(void) successfulPurchase:(IAPHelper*)ebp restored:(bool)isRestore identifier:(NSString*)productId receipt:(NSData*)transactionReceipt;
-(void) incompleteRestore:(IAPHelper*)ebp;
-(void) failedRestore:(IAPHelper*)ebp error:(NSInteger)errorCode message:(NSString*)errorMessage;

@end
