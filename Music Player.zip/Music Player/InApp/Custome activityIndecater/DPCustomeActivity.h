//
//  DPCustomeActivity.h
//  DriverProfile
//
//  Created by EffOne Development Team on 06/10/14.
//  Copyright (c) 2014 EffOne Software. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface DPCustomeActivity : NSObject<UINavigationControllerDelegate>
{
    UIView* view,*actiIdecaterView;
    UIView *IndicatorView;
	UIActivityIndicatorView* wait;
	UILabel* busyLabel;
	int busyCount;
    UIButton *CancelButton;
    
    BOOL isAnimating;
    int circleNumber;
    int maxCircleNumber;
    float circleSize;
    float radius;
    UIColor *color;
    NSTimer *circleDelay;
}

/* Pass 'YES' if want to show activity indicator. 'NO' if you want to stop animating */
- (void) makeBusy:(BOOL)yesOrno;
- (void) forceRemoveBusyState;

+ (DPCustomeActivity*)defaultAgent;


@property (nonatomic,retain) UIColor *color;

-(void)showTheBusyWithTitle:(NSString*)title;
-(void)removeTheBusy;


-(void)startAnimating;

-(void)stopAnimating;

-(BOOL)isAnimating;

@end
