//
//  DPCustomeActivity.m
//  DriverProfile
//
//  Created by EffOne Development Team on 06/10/14.
//  Copyright (c) 2014 EffOne Software. All rights reserved.
//

#import "DPCustomeActivity.h"
static DPCustomeActivity* agent;
#define APPLICATION_COLOR_BLUE [UIColor colorWithRed:0.247 green:0.698 blue:0.957 alpha:1.0]//lightly blue



@implementation DPCustomeActivity
@synthesize color;

- (id)init
{
	return nil;
}

- (id)myinit
{
    
    if(self == [super init])
    {
		busyCount = 0;
        
        view= [[UIView alloc] initWithFrame:CGRectMake(0,0,320,460)];


        if([[UIScreen mainScreen]bounds].size.height == 568)
        {
            view.frame = CGRectMake(0,0,320,568);
        }
        else
        {
            view.frame = CGRectMake(0,0,320,480);
        }
        
        
        view= [[UIView alloc]init];
        view.frame =  [[[UIApplication sharedApplication] keyWindow] frame];
        [view.layer setCornerRadius:10.0f];
        view.backgroundColor = [UIColor clearColor];
        
        UIImageView *imageView = [[UIImageView alloc] init];
        [imageView setFrame:CGRectMake(0, 0, view.frame.size.width, view.frame.size.height)];
        imageView.alpha = .7;
        imageView.layer.cornerRadius = 12;
        [imageView setBackgroundColor:[UIColor blackColor]];
        [view addSubview:imageView];
        
        
         UIImageView *imageVieInner = [[UIImageView alloc] init];
        [imageVieInner setFrame:CGRectMake(2, 0, view.frame.size.width, view.frame.size.height)];
        imageVieInner.layer.borderWidth = 1;
        imageVieInner.layer.borderColor = [UIColor grayColor].CGColor;
        imageVieInner.layer.cornerRadius = 12;
        [view addSubview:imageVieInner];

        
        actiIdecaterView= [[UIView alloc] initWithFrame:CGRectMake(view.frame.size.width /2 - 30,view.frame.size.height /2 - 30,60,60)];
        actiIdecaterView.backgroundColor = [UIColor clearColor];
        [view addSubview:actiIdecaterView];
        self.color = APPLICATION_COLOR_BLUE;
        
        wait = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleWhiteLarge];
        wait.backgroundColor = [UIColor clearColor];
		wait.hidesWhenStopped = NO;
        [wait setColor:[UIColor whiteColor]];


        [view addSubview:wait];
        [wait startAnimating ];
        wait.layer.cornerRadius = 12.0;
        
        //    [self commonInit];
        //     [self playTheCircle];
                
        busyLabel = [[UILabel alloc] init];
        busyLabel.textColor = [UIColor grayColor];
        busyLabel.numberOfLines = 2;
        busyLabel.backgroundColor = [UIColor clearColor];
        busyLabel.text = @"Processing... Please wait";
        [busyLabel setFont:[UIFont systemFontOfSize:13]];
        busyLabel.textAlignment = NSTextAlignmentCenter;
		[view addSubview:busyLabel];
        
        [imageView setFrame:CGRectMake(0, 0,130, 120)];
        [imageView setCenter:CGPointMake(view.frame.size.width / 2 , view.frame.size.height / 2 + 20)];
        [imageVieInner setFrame:CGRectMake(20, 20,110, 100)];
        [imageVieInner setCenter:CGPointMake(view.frame.size.width / 2  , view.frame.size.height / 2 + 20)];
        [busyLabel setFrame:CGRectMake(view.frame.size.width /2 - 50,view.frame.size.height /2 + 18,100,60)];
        [wait setFrame:CGRectMake(view.frame.size.width /2 - 30,view.frame.size.height /2 - 25,60,60)];
        actiIdecaterView.frame = CGRectMake(view.frame.size.width /2 - 30,view.frame.size.height /2 - 26,60,60);
		return self;
    }
    else
    {
        return nil;
    }
}
-(void)showTheBusyWithTitle:(NSString*)title
{
    busyLabel.text = title;
    busyCount++;
    [self makeBusyYes_No];
}
-(void)removeTheBusy
{
    busyCount--;
    if(busyCount<0)
    {
        busyCount = 0;
    }
    [self makeBusyYes_No];
}
-(void)makeBusyYes_No
{
    if(busyCount == 1)
    {
		[[[UIApplication sharedApplication] keyWindow] addSubview:view];
		[[[UIApplication sharedApplication] keyWindow] bringSubviewToFront:view];
	}
    else if(busyCount == 0)
    {
		[view removeFromSuperview];
	}
    else
    {
		[[[UIApplication sharedApplication] keyWindow] bringSubviewToFront:view];
	}
}
- (void) makeBusy:(BOOL)yesOrno
{
	if(yesOrno)
    {
		busyCount++;
	}
    else
    {
		busyCount--;
		if(busyCount<0)
        {
			busyCount = 0;
		}
	}
	if(busyCount == 1){
		[[[UIApplication sharedApplication] keyWindow] addSubview:view];
		[[[UIApplication sharedApplication] keyWindow] bringSubviewToFront:view];
	}else if(busyCount == 0) {
		[view removeFromSuperview];
	}else {
		[[[UIApplication sharedApplication] keyWindow] bringSubviewToFront:view];
	}
}

- (void) forceRemoveBusyState{
	busyCount = 0;
	[view removeFromSuperview];
}
+ (DPCustomeActivity*)defaultAgent{
	if(!agent)
    {
		agent =[[DPCustomeActivity alloc] myinit];
	}
	return agent;
}
- (void)playTheCircle
{
    if (!isAnimating)
    {
        [self stopAnimating];
        [self performSelector:@selector(startAnimating) withObject:nil afterDelay:0];
    }
}
-(void)startAnimating{
    
    if (!isAnimating)
    {
        isAnimating = YES;
        
        circleNumber = 0;
        
        radius = actiIdecaterView.frame.size.width/2;
        
        if (actiIdecaterView.frame.size.width > actiIdecaterView.frame.size.height){
            radius = actiIdecaterView.frame.size.height/2;
        }
        circleSize = 15*radius/55;
        //add circles
        circleDelay = [NSTimer scheduledTimerWithTimeInterval: 0.20 target: self
                                                     selector: @selector(nextCircle) userInfo: nil repeats: YES];
    }
}
-(void)nextCircle{
    if (circleNumber<maxCircleNumber){
        circleNumber ++;
        
        CGRect f = CGRectMake((actiIdecaterView.frame.size.width-circleSize)/2 - 1, actiIdecaterView.frame.size.height-circleSize -1, circleSize -4 , circleSize -4);
        CAShapeLayer *circleLayer = [CAShapeLayer layer];
        circleLayer.frame = f;
        f.origin.x=0;
        f.origin.y=0;
        circleLayer.path = CGPathCreateWithEllipseInRect(f,nil);
        circleLayer.fillColor = self.color.CGColor;
        [actiIdecaterView.layer addSublayer:circleLayer];
        
        CGMutablePathRef circlePath = CGPathCreateMutable();
        CGPathMoveToPoint(circlePath, NULL, actiIdecaterView.frame.size.width/2, actiIdecaterView.frame.size.height-circleSize/2);
        
        CGPathAddArc(circlePath, NULL, actiIdecaterView.frame.size.width/2, actiIdecaterView.frame.size.height/2, radius-15/2, M_PI_2, -M_PI_2*3, NO);
        
        CAKeyframeAnimation *circleAnimation = [CAKeyframeAnimation animationWithKeyPath:@"position"];
        circleAnimation.duration = 1.5;
        circleAnimation.timingFunction = [CAMediaTimingFunction functionWithControlPoints:0.15f :0.60f :0.85f :0.4f];
        [circleAnimation setCalculationMode:kCAAnimationPaced];
        circleAnimation.path = circlePath;
        circleAnimation.repeatCount = HUGE_VALF;
        [circleLayer addAnimation:circleAnimation forKey:@"circleAnimation"];
        
        CGPathRelease(circlePath);
        
    } else {
        [circleDelay invalidate];
    }
}
-(void)stopAnimating
{
    isAnimating = NO;
    for (UIView *v in actiIdecaterView.subviews){
        [v removeFromSuperview];
    }
}

-(BOOL)isAnimating{
    return isAnimating;
}

- (void)commonInit
{
    isAnimating = NO;
    maxCircleNumber = 5;
}


@end
