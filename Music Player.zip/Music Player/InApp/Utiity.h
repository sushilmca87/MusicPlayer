//
//  Utiity.h
//  SwiftHandBook
//
//  Created by sushil on 29/06/15.
//  Copyright (c) 2015 sushil. All rights reserved.
//


//r#define READ_TEXT_FONT "Avenir Next LT Pro"
#define READ_TEXT_FONT "Aileron"
#define READ_TEXT_FONT_BPLD "Aileron-SemiBold"
#define HELVETICA_TEXT_FONT "Helvetica Neue"
#define  APP_IMAGE @"iconApp.png"







#define TWITTER_ACCOUNT_NAME @"coloriesadult"
#define FACEBOOK_ACCOUNT_NAME @"583394531994865"


#define FOLLOW_US_ON_TWITTER @"https://twitter.com/coloriesadult"
#define LIKE_US_ON_FACEBOOK @"https://www.facebook.com/Kishore-Kumar-Top-Song-583394531994865/"
//#define RATE_OF_APP @"https://itunes.apple.com/us/app/kishore-kumar-top-song/id1360758422?ls=1&mt=8"


#define RATE_OF_APP @"https://itunes.apple.com/app/viewContentsUserReviews?id=1360758422"
#define APP_NAME @"Kishore Songs"

#define SUBJECT_FEEDBACK @"Kishore Kumar Song - Kishore top song feedback"
#define SUBJECT_HELP @"Kishore Kumar Song - Kishore top song support needed!"
#define  RECOMMENDS_BODY APP_NAME
#define RECOMMENDS_SUBJECT APP_NAME



#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
@interface Utiity : NSObject
+(UIColor*)getTextColor;
+(UIColor*)getBgCollectionViewTableColor;
+(UIColor*)getBgColor;
+(UIColor*)getWthoutCodeColor;
+(NSAttributedString*)getColorRangeMutableTextString:(UITextView*)textLbl;
+(void)setSelectedChapterByUser:(NSString*)chapterName;
+(NSString*)getSelectedChapterByUser;
+(UIColor*)getCircleColor;
+(UIColor*)getChapterColor;
+(UIColor*)getCircleColorWithHighleted;
+(NSAttributedString*)getColorRangeMutableTextStringWithTheDescription:(UILabel*)textLbl;
+(float)getWindowRatio:(CGRect)frame;
+(UIColor*)getTextCircleColor;
+(UIColor*)getBlackTextColor;
+(BOOL)getIsUserHasPurchasedItemFromAppStore;
+(void)setIsUserHasPurchasedItemFromAppStore:(BOOL)isPurchase;
+(UIColor*)getAppGreeNColor;
+(UIColor*)getGreeTextNColor;
+(void)setUsrerHasShairedThisAppOnFacOrTwitter:(BOOL)isShaire;
+(BOOL)getUserHasSharedOr_Not;

+(UIColor*)getTableBckgroundColor;
+(UIColor*)getDarkGreenClor;
+(UIColor*)getBlueColorColor;
+(UIColor*)getOuterCircleClorCombination;
+(UIColor*)getViewControllerColoerBcakgroundColor;

+(Utiity*)sharedInstance;
+(UIColor*)getWthoutCodeColor12;
+(UIColor*)getBgCollectionViewTableColor12;
+(UIColor*)getTextColor12;

+(BOOL)getIsBackgroundMusicsEnable;
+(void)setgetIsBackgroundMusicsEnable:(BOOL)enable;


+(BOOL)getIsDefaultSettingEnable;
+(void)setDefaulteSettingEnable:(BOOL)enable;

-(void)playBackgroungAudio;
-(void)stopPlayBckgroundMusicActionByUser;
+(UIColor*)getNaviBarColor;
-(void)setPurchaseRequest;

+(void)setMonthlyOrYearlySubscribe:(BOOL) isSubscribe;
+(BOOL)isMonthlyOrYearlySubscribe;


+(NSString*)trailPurchasePrice;
    +(void)setTrailPurchasePrice:(NSString*)price;
        +(NSString*)monthlyPurchasePrice;
            +(void)setMonthlyPurchasePrice:(NSString*)price;
                +(NSString*)yearlyPurchasePrice;
                    +(void)setYearlyPurchasePrice:(NSString*)price;


@end
