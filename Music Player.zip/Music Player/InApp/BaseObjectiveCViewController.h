//
//  BaseObjectiveCViewController.h
//  LinuxCmdPro
//
//  Created by SushilKumar Singh on 2/3/18.
//  Copyright © 2018 Effone. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BaseObjectiveCViewController : UIViewController

@end
