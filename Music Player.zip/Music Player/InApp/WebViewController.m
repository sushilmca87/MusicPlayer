//
//  WebViewController.m
//  Colories
//
//  Created by SushilKumar Singh on 5/27/17.
//  Copyright © 2017 Effone. All rights reserved.
//

#import "WebViewController.h"

@interface WebViewController (){
    NSURLRequest *request ;
}
@property (weak, nonatomic) IBOutlet UIWebView *mWebView;

@end

@implementation WebViewController
@synthesize selectedIndex;

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.navigationController.navigationBarHidden = false;
    

    
    self.navigationItem.title = self.titleNavi;
    
    request = [NSURLRequest requestWithURL:[self getSelectedURL]];
    
    if(selectedIndex == 4){
        
        NSString *bundle = [[NSBundle mainBundle] pathForResource:@"AboutSubscription" ofType:@"html"];
        NSString *path = [NSString stringWithContentsOfFile:bundle encoding:NSUTF8StringEncoding error:nil];
        [_mWebView loadHTMLString:path baseURL:[[NSBundle mainBundle] bundleURL]];
        
        
    }else{
        [_mWebView loadRequest:request];
    }
    
    // Do any additional setup after loading the view from its nib.
}
-(BOOL)prefersStatusBarHidden{
    return UIStatusBarStyleLightContent;
}
-(NSURL*)getSelectedURL{
    
    NSURL *url = nil;
    if(selectedIndex == 2){
        //Privacy policy
       url = [NSURL URLWithString:@"http://www.iapptechnology.com/private-policy"];
    }else if(selectedIndex == 3){
        
        //Terms of use
        url = [NSURL URLWithString:@"http://www.iapptechnology.com/term"];
    }else{
        
        //about susbscription
        url = [NSURL URLWithString:@"http://www.iapptechnology.com/private-policy"];
    }
    return url;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
