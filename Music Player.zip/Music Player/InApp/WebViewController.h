//
//  WebViewController.h
//  Colories
//
//  Created by SushilKumar Singh on 5/27/17.
//  Copyright © 2017 Effone. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BaseObjectiveCViewController.h"


@interface WebViewController : BaseObjectiveCViewController
@property(nonatomic,assign)NSInteger selectedIndex;
@property(nonatomic,strong)NSString *titleNavi;


@end
