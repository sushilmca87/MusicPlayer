//
//  PurchaseView.m
//  Colories
//
//  Created by Sushil on 11/7/16.
//  Copyright © 2016 Effone. All rights reserved.
//

#import "PurchaseView.h"
#import "Utiity.h"
#import "MKStoreKit.h"
#import "DPCustomeActivity.h"
#import "Music-Swift.h"

@interface PurchaseView(){
    float quantityMultiply;
    Reachability *reachability;
    
    UILabel *trialValueLable;
    UILabel *monthlyValueLable;
    UILabel *earlyValueLable;
 
}
@end
@implementation PurchaseView

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/
-(id)initWithFrame:(CGRect)frame{
    self = [super initWithFrame:frame];
    if(self ){
        [self addComponnets];
    }
    return self;
}
-(void)setPrice {
    
    NSString *trialPrice = [Utiity monthlyPurchasePrice];
    if(trialPrice == nil || trialPrice.length <= 1){
        trialPrice  = [@"Get It" uppercaseString];
    }else{
        trialPrice  = [@"Free" uppercaseString];
    }
    trialValueLable.text = trialPrice;
    NSString *monthlyPrice = [Utiity monthlyPurchasePrice];
    if(monthlyPrice == nil || monthlyPrice.length <= 1){
        monthlyPrice  = [@"Get It" uppercaseString];
    }
    monthlyValueLable.text = monthlyPrice;
    
    
    NSString *yearlyPrice = [Utiity yearlyPurchasePrice];
    if(yearlyPrice == nil || yearlyPrice.length <= 1){
        yearlyPrice  = [@"Get It" uppercaseString];
    }
    earlyValueLable.text = yearlyPrice;
}
-(void)addComponnets{
    
    
    reachability = [[Reachability alloc] init];
    
    
    
    quantityMultiply = [Utiity getWindowRatio:self.bounds];
    self.backgroundColor = [UIColor blackColor];
    
    float width = 30*quantityMultiply;
    
    _crossBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    [_crossBtn setFrame:CGRectMake(self.frame.size.width - 40*quantityMultiply, 20, width, width)];
    [_crossBtn setBackgroundImage:[UIImage imageNamed:@"cross.png"] forState:UIControlStateNormal];
    [_crossBtn addTarget:self action:@selector(crossAction) forControlEvents:UIControlEventTouchUpInside];
    [self addSubview:_crossBtn];
    _crossBtn.alpha = 0.5;
    
    
    
    UIImageView *appIcon = [[UIImageView alloc]init];
    appIcon.frame = CGRectMake(self.frame.size.width/2 - 45*quantityMultiply, 70*quantityMultiply, 90*quantityMultiply, 90*quantityMultiply);
    //    appIcon.backgroundColor = defaulteColor;
    appIcon.image = [UIImage imageNamed:@"iconApp.png"];
    [self addSubview:appIcon];
    
    UILabel *titleLable = [[UILabel alloc]init];
    titleLable.frame = CGRectMake(0, appIcon.frame.origin.y + appIcon.frame.size.height, self.frame.size.width,50*quantityMultiply);
    titleLable.text = [APP_NAME uppercaseString];
    titleLable.font = [UIFont systemFontOfSize:25*quantityMultiply];
    titleLable.textAlignment = NSTextAlignmentCenter;
    titleLable.textColor = [UIColor whiteColor];
    [self addSubview:titleLable];
    
    
    UILabel *unlimitedLable = [[UILabel alloc]init];
    unlimitedLable.frame = CGRectMake(0, titleLable.frame.origin.y + titleLable.frame.size.height,self.frame.size.width, 80*quantityMultiply);
    unlimitedLable.text = @"UNLIMITED ACCESS MILION SONGS FOR FREE.\n GET LATEST SONG ANY TIME ANY WHERE.\n NO COMMITMENT, YOU CAN CANCEL ANYTIME. \n DOWNLOAD THE MILION OF SONG ONLY ON MONTHLY AND YEARLY SUBSCRIPTION";
    unlimitedLable.font = [UIFont systemFontOfSize:11*quantityMultiply];
    unlimitedLable.textAlignment = NSTextAlignmentCenter;
    unlimitedLable.alpha = 0.5;
    unlimitedLable.textColor = [UIColor whiteColor];
    unlimitedLable.numberOfLines = 0;
    [self addSubview:unlimitedLable];
    
    
    
    UIFont *systemfont = [UIFont systemFontOfSize:17*quantityMultiply];
    UIColor *defaulteColor = [UIColor colorWithWhite:.3 alpha:1];;
    float yCord = unlimitedLable.frame.origin.y + unlimitedLable.frame.size.height + 10*quantityMultiply;
   
    
    
    
    
    
    
    // add Trial View
    UIView *trialView = [[UIView alloc]init];
    trialView.frame = CGRectMake(10, yCord, self.frame.size.width - 20*quantityMultiply, 50*quantityMultiply);
    trialView.backgroundColor = defaulteColor;
    [self addSubview:trialView];
    trialView.layer.cornerRadius = 7.0;
    
    
    UILabel *trialLable = [[UILabel alloc]init];
    trialLable.frame = CGRectMake(10, 0, self.frame.size.width/2, trialView.frame.size.height);
    trialLable.text = [@"Trial" uppercaseString];
    trialLable.font = systemfont;
    trialLable.textColor = [UIColor whiteColor];

    trialLable.textAlignment = NSTextAlignmentLeft;
    [trialView addSubview:trialLable];
    
    NSString *trialPrice = [Utiity monthlyPurchasePrice];
    if(trialPrice == nil || trialPrice.length <= 1){
        trialPrice  = [@"Get It" uppercaseString];
    }else{
        trialPrice  = [@"Free" uppercaseString];
    }

    
    trialValueLable = [[UILabel alloc]init];
    trialValueLable.frame = CGRectMake(trialView.frame.size.width/2, 0, trialView.frame.size.width/2- 10*quantityMultiply, trialView.frame.size.height);
    trialValueLable.text = trialPrice;
    trialValueLable.textColor = [UIColor whiteColor];

    trialValueLable.font = systemfont;
    trialValueLable.textAlignment = NSTextAlignmentRight;
    [trialView addSubview:trialValueLable];
    
    UIButton *trailBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    [trailBtn setFrame:trialView.bounds];
    [trailBtn addTarget:self action:@selector(trailAction) forControlEvents:UIControlEventTouchUpInside];
    [trialView addSubview:trailBtn];
    // end Trial View
    
    
    
    // add MonthlyView View
    yCord = yCord + trialView.frame.size.height + 10*quantityMultiply;
    UIView *MonthlyView = [[UIView alloc]init];
    MonthlyView.frame = CGRectMake(10, yCord, self.frame.size.width - 20*quantityMultiply, trialView.frame.size.height);
    MonthlyView.backgroundColor = defaulteColor;
    MonthlyView.layer.cornerRadius = 7.0;


    [self addSubview:MonthlyView];
    
    
    UILabel *MonthlyLable = [[UILabel alloc]init];
    MonthlyLable.frame = CGRectMake(10*quantityMultiply, 0, trialView.frame.size.width/2 , trialView.frame.size.height);
    MonthlyLable.text = [@"1 Month" uppercaseString];
    MonthlyLable.font = systemfont;
    MonthlyLable.textColor = [UIColor whiteColor];

    [MonthlyView addSubview:MonthlyLable];
    
    
    monthlyValueLable = [[UILabel alloc]init];
    monthlyValueLable.frame = CGRectMake(trialView.frame.size.width/2, 0, trialView.frame.size.width/2 - 10*quantityMultiply, trialView.frame.size.height);
    
    NSString *monthlyPrice = [Utiity monthlyPurchasePrice];
    if(monthlyPrice == nil || monthlyPrice.length <= 1){
       monthlyPrice  = [@"Get It" uppercaseString];
    }
    monthlyValueLable.text = monthlyPrice;
    monthlyValueLable.font = systemfont;
    monthlyValueLable.textColor = [UIColor whiteColor];

    monthlyValueLable.textAlignment = NSTextAlignmentRight;
    [MonthlyView addSubview:monthlyValueLable];
    
    UIButton *monthlyBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    [monthlyBtn setFrame:MonthlyView.bounds];
    [monthlyBtn addTarget:self action:@selector(monthlyAction) forControlEvents:UIControlEventTouchUpInside];
    [MonthlyView addSubview:monthlyBtn];
    // end MonthlyView View
    
    
    
    // add earlyView View
    yCord = yCord + MonthlyView.frame.size.height + 10*quantityMultiply;
    UIView *earlyView = [[UIView alloc]init];
    earlyView.frame = CGRectMake(10*quantityMultiply, yCord, self.frame.size.width - 20*quantityMultiply, trialView.frame.size.height);
    earlyView.backgroundColor = defaulteColor;
    earlyView.layer.cornerRadius = 7.0;

    [self addSubview:earlyView];
    
    
    UILabel *earlyLable = [[UILabel alloc]init];
    earlyLable.frame = CGRectMake(10, 0, trialView.frame.size.width/2, trialView.frame.size.height);
    earlyLable.text = [@"1 Year" uppercaseString];
    earlyLable.font = systemfont;
    earlyLable.textColor = [UIColor whiteColor];

    earlyLable.textAlignment = NSTextAlignmentLeft;
    [earlyView addSubview:earlyLable];
    
    
    NSString *yearlyPrice = [Utiity yearlyPurchasePrice];
    if(yearlyPrice == nil || yearlyPrice.length <= 1){
        yearlyPrice  = [@"Get It" uppercaseString];
    }
    
    earlyValueLable = [[UILabel alloc]init];
    earlyValueLable.frame = CGRectMake(trialView.frame.size.width/2, 0, trialView.frame.size.width/2- 10*quantityMultiply, trialView.frame.size.height);
    earlyValueLable.text = yearlyPrice;
    earlyValueLable.font = systemfont;
    earlyValueLable.textColor = [UIColor whiteColor];


    earlyValueLable.textAlignment = NSTextAlignmentRight;
    [earlyView addSubview:earlyValueLable];
    
    UIButton *earlyBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    [earlyBtn setFrame:earlyView.bounds];
    [earlyBtn addTarget:self action:@selector(yearlyAction) forControlEvents:UIControlEventTouchUpInside];
    [earlyView addSubview:earlyBtn];
    // end early View View
    
    
    
    UILabel *allreadySubscribeLable = [[UILabel alloc]init];
    allreadySubscribeLable.frame = CGRectMake(0, self.frame.size.height- 80*quantityMultiply,self.frame.size.width, 40);
    allreadySubscribeLable.text = @"ALREADY A SUBSCRIBER?";
    allreadySubscribeLable.font = [UIFont systemFontOfSize:15*quantityMultiply];
    allreadySubscribeLable.textAlignment = NSTextAlignmentCenter;
    allreadySubscribeLable.alpha = 0.5;
    allreadySubscribeLable.textColor = [UIColor whiteColor];
    [self addSubview:allreadySubscribeLable];

    
    UIButton  *restoreBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    [restoreBtn setFrame:CGRectMake(0, allreadySubscribeLable.frame.origin.y + allreadySubscribeLable.frame.size.height - 5*quantityMultiply, self.frame.size.width, 30*quantityMultiply)];
//    restoreBtn.layer.cornerRadius = 5*quantityMultiply;
//    restoreBtn.layer.borderWidth = 1;
    restoreBtn.layer.borderColor = [UIColor colorWithWhite:.7 alpha:.5].CGColor;
    [restoreBtn setTitle:@"RESTORE" forState:UIControlStateNormal];
    restoreBtn.titleLabel.font = [UIFont systemFontOfSize:15*quantityMultiply];
    [restoreBtn setTitleColor:[UIColor grayColor] forState:UIControlStateNormal];
    [restoreBtn addTarget:self action:@selector(restoreAction) forControlEvents:UIControlEventTouchUpInside];
    [self addSubview:restoreBtn];
    

    
    
    [[NSNotificationCenter defaultCenter] removeObserver:self];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(purchaseFailedNotification) name:kMKStoreKitProductPurchaseFailedNotification object:nil];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(purchaseRestoreFailedFailedNotification) name:kMKStoreKitRestoringPurchasesFailedNotification object:nil];

    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(productPurchasedSuccessfully:) name:kMKStoreKitProductPurchasedNotification object:nil];
    
    
    
    

}

-(void)productPurchasedSuccessfully:(NSNotification*)notify{
    
    NSString *identifier = (NSString*)notify.userInfo;
    if ([identifier isEqualToString: MONTHLY_PURCHASE] | [identifier isEqualToString: YEARLY_PURCHASE]) {
        [self setMonthlyOrYearlySubscribe:true];
    }else{
        [self setMonthlyOrYearlySubscribe:false];
    }
    NSLog(@"Purchased product with sushil: \(note.object)");
    [[DPCustomeActivity defaultAgent] makeBusy:false];
    [self crossAction];
}
-(void)setMonthlyOrYearlySubscribe:(BOOL) isSubscribe{
    [Utiity setMonthlyOrYearlySubscribe:isSubscribe];
}
-(BOOL)isMonthlyOrYearlySubscribe{
    return [Utiity isMonthlyOrYearlySubscribe];
}
-(void)purchaseFailedNotification{
    [[DPCustomeActivity defaultAgent] makeBusy:false];
}
-(void)purchaseRestoreFailedFailedNotification{
    [[DPCustomeActivity defaultAgent] makeBusy:false];
}



-(void)restoreAction{
    
    if([self checkNetworkStatus])
    {
        [[MKStoreKit sharedKit] restorePurchases];
        [[DPCustomeActivity defaultAgent] makeBusy:true];
        
    }

}
-(void)trailAction{
    if([self checkNetworkStatus])
    {
        [[MKStoreKit sharedKit] initiatePaymentRequestForProductWithIdentifier:TRAIL_PURCHASE];
        [[DPCustomeActivity defaultAgent] makeBusy:true];
    }
}
-(void)monthlyAction{
    
    if([self checkNetworkStatus])
    {
        [[MKStoreKit sharedKit] initiatePaymentRequestForProductWithIdentifier:MONTHLY_PURCHASE];
        [[DPCustomeActivity defaultAgent] makeBusy:true];
    }
}
-(void)yearlyAction{
    
    if([self checkNetworkStatus])
    {
        [[MKStoreKit sharedKit] initiatePaymentRequestForProductWithIdentifier:YEARLY_PURCHASE];
        [[DPCustomeActivity defaultAgent] makeBusy:true];
    }
}
-(BOOL)isReachble {
    ReachablityCustome *reachable = [[ReachablityCustome alloc]init];
    if ([reachable isInternetConnectionReachable] == true){
        return true;
    }else{
        return false;

    }
}

-(NSInteger)checkNetworkStatus
{
    if ([self isReachble] == true)
    {
        return 1;
    }
    else
    {
        
        NSString  *malert1=@"Network Status";
        NSString  *malert2=@"Please check your Internet connection and try again.";
        [[[UIAlertView alloc]initWithTitle:malert1 message:malert2 delegate:self cancelButtonTitle:@"Ok" otherButtonTitles:nil, nil]show];
        return 0;
    }
}

-(void)crossAction{
    [UIView animateWithDuration:0.5 animations:^{
        self.frame = CGRectMake(0, [[UIScreen mainScreen]bounds].size.height, self.frame.size.width,self.frame.size.height);
    } completion:^(BOOL finished) {
    }];
}


@end
