//
//  BaseObjectiveCViewController.m
//  LinuxCmdPro
//
//  Created by SushilKumar Singh on 2/3/18.
//  Copyright © 2018 Effone. All rights reserved.
//

#import "BaseObjectiveCViewController.h"
#import "Utiity.h"

@interface BaseObjectiveCViewController ()

@end

@implementation BaseObjectiveCViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self setUpUI];
    // Do any additional setup after loading the view.
}

-(UIStatusBarStyle)preferredStatusBarStyle{
    return UIStatusBarStyleLightContent;
}
-(void)setUpUI{
 

    self.navigationController.navigationBar.barTintColor = [Utiity getNaviBarColor];
    self.navigationController.navigationBar.tintColor = [UIColor whiteColor];
    self.navigationController.navigationBar.titleTextAttributes = [NSDictionary dictionaryWithObjectsAndKeys:
                                                                   [UIColor whiteColor], UITextAttributeTextColor, nil];
    self.navigationController.navigationBar.barStyle = UIBarStyleBlack;
    self.navigationController.navigationBar.translucent = false;


}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
