//
//  SettingViewController.m
//  Shafdfdgf
//
//  Created by SushilKumar on 7/8/15.
//  Copyright (c) 2015 Effone. All rights reserved.
//

#import "SettingViewController.h"
#import <sys/utsname.h>
#import <MessageUI/MessageUI.h>
#import <StoreKit/StoreKit.h>
#import "RageIAPHelper.h"
#import "WebViewController.h"
#import "Utiity.h"
#import "MKStoreKit.h"
#import "DPCustomeActivity.h"
#import "Music-Swift.h"

#define CELL_HIEGHT 70
#define NAVIGATION_BAR 70



@interface SettingViewController ()<UITableViewDataSource,UITableViewDelegate,MFMailComposeViewControllerDelegate,IAPHelperDelegate>
{
    NSMutableArray *contentArray;
    NSArray *imageListArray;
    UITableView *infoLTbaleView;
    NSArray *headerList;
    float quantityMultiply;
    
    // send a mail action
    BOOL isDoneMailAction;
    BOOL isFeedBackAction;
    NSArray *_products;
    BOOL isPurchased;
    BOOL isBuyButtoneClick;
    
    
    
}
@property (nonatomic,strong)PurchaseView *purchaseView;

@end
@implementation SettingViewController
@synthesize purchaseView = _purchaseView;

- (void)viewDidLoad {
    [super viewDidLoad];
    
    //NSLog(@"Rect == %@",NSStringFromCGRect(self.view.frame));
    
    quantityMultiply = [Utiity getWindowRatio:self.view.frame];
    
    headerList = @[@"Wish",@"Feedback",@"About us",@"Add",@"Support",@"Setting"];
    
    
//    contentArray = [[NSMutableArray alloc]initWithObjects:@[@"Recommend",@"Rate of App"],@[@"Feedback",@"Help"],@[@"Like us on  Facebook"],@[@"Remove Add",@"Restore Purchases"],@[@"Report problem"],@[@"Background Musics"],nil];
//    
//    imageListArray = [[NSMutableArray alloc]initWithObjects:@[@"recomends.png",@"rate.png"],@[@"feedback.png",@"help.png"],@[@"facbook.png"],@[@"removeAdd.png",@"restore.png"],@[@"report.png"],@[@""],nil];
//    
    
    
    contentArray = [[NSMutableArray alloc]initWithObjects:@[@"Recommend",@"Rate of App"],@[@"Feedback",@"Help"],@[@"Like us on  Facebook",@"Like us on Twitter"],@[@"Restore",@"Manage subscriptions",@"Privacy Policy",@"Terms of Use",@"About Subscription"],@[@"Report problem"],nil];
    
    imageListArray = [[NSMutableArray alloc]initWithObjects:@[@"recomends.png",@"rate.png"],@[@"feedback.png",@"help.png"],@[@"facbook.png",@"twitter.png"],@[@"restore.png",@"Subscribe.png",@"Privacy Policy.png",@"TermsofUse.png",@"Subscribe.png"],@[@"report.png"],nil];
    
    
    self.view.backgroundColor = [UIColor blackColor];
    
    UIImageView *bgImageView = [[UIImageView alloc]initWithFrame:self.view.bounds];
    [bgImageView setImage:[UIImage imageNamed:@"bgImage.jpg"]];
    //[self.view addSubview:bgImageView];
    
//    UIView *bgView = [[UIView alloc]initWithFrame:bgImageView.bounds];
//    bgView.backgroundColor = BG_COLOR;
//    bgView.alpha = .8;
//    [self.view addSubview:bgView];
    

    
    
    // Do any additional setup after loading the view.
    infoLTbaleView = [[UITableView alloc]initWithFrame:self.view.bounds style:UITableViewStyleGrouped];
    infoLTbaleView.dataSource = self;
    infoLTbaleView.delegate = self;
    infoLTbaleView.rowHeight = 50*quantityMultiply;
    infoLTbaleView.backgroundColor = [UIColor clearColor];
    [infoLTbaleView  setShowsVerticalScrollIndicator:NO];
    [self.view addSubview:infoLTbaleView];
    infoLTbaleView.backgroundColor = [UIColor clearColor];
    infoLTbaleView.backgroundView = nil;
    infoLTbaleView.frame = CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height - ( 50*quantityMultiply));

    
    
    
    self.navigationItem.title = @"Setting";
    UILabel *chapterLbl = (UILabel*)[self.navigationController.view viewWithTag:111];
    chapterLbl.text = @"Support";
    
//    [self addPurchaseNotification];


    
    [self show_Hide_FrameView];
    
    [self reloadTableViewContent];
    
    self.navigationController.navigationBarHidden = false;
    
    UIBarButtonItem *rightBtn = [[UIBarButtonItem alloc]initWithTitle:@"Cancel" style:UIBarButtonItemStylePlain target:self action:@selector(cancelPage)];
    self.navigationItem.rightBarButtonItem = rightBtn;
    
  
    
//    [[ShowAddView sharedInstance] showFullScreenAdMobsViewWithCondition];
    
    
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(purchaseRestoreFailedFailedNotification) name:kMKStoreKitRestoringPurchasesFailedNotification object:nil];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(productPurchasedSuccessfully) name:kMKStoreKitProductPurchasedNotification object:nil];


    
}
-(void)cancelPage{
    [self.navigationController dismissViewControllerAnimated:true completion:nil];
}


-(PurchaseView*)purchaseView{
    if(_purchaseView == nil){
        _purchaseView = [[PurchaseView alloc]initWithFrame:CGRectMake(0, self.view.frame.size.height, self.view.frame.size.width,[UIScreen mainScreen].bounds.size.height) ];
        [self.navigationController.view addSubview:_purchaseView];
    }
    return _purchaseView;
}
-(void)showPurchasePopUp{
    _purchaseView = [self purchaseView];
    [_purchaseView setPrice];
    _purchaseView.crossBtn.alpha = 0;
    _purchaseView.crossBtn.userInteractionEnabled = false;
    self.purchaseView.translatesAutoresizingMaskIntoConstraints = NO;

    [UIView animateWithDuration:0.5 animations:^{
        _purchaseView.frame = CGRectMake(0, 0, self.view.frame.size.width,[UIScreen mainScreen].bounds.size.height);
        [_purchaseView setAutoresizingMask:UIViewAutoresizingFlexibleHeight];

    } completion:^(BOOL finished) {
        [self performSelector:@selector(enableCrossBtn) withObject:nil afterDelay:4];
    }];
    
    
}
-(void)enableCrossBtn{
    _purchaseView.crossBtn.alpha = 1;
    _purchaseView.crossBtn.userInteractionEnabled = true;
    
}

-(UIStatusBarStyle)preferredStatusBarStyle{
    return UIStatusBarStyleLightContent;
}

-(void)reloadTableViewContent{
    
}
-(void)show_Hide_FrameView{
    
    CGRect frame = infoLTbaleView.frame;
    if(![Utiity getIsUserHasPurchasedItemFromAppStore]){
        frame.size.height = frame.size.height - 50*quantityMultiply;
        infoLTbaleView.frame = frame;
    }else {
        frame.size.height = frame.size.height + 35*quantityMultiply ;
        infoLTbaleView.frame = frame;
    }
}

-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return [contentArray count];
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [[contentArray objectAtIndex:section] count];
}
-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return (40*quantityMultiply);
}
-(UIView*)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    UIView *headerView = [[UIView alloc]initWithFrame:CGRectZero];
    headerView.backgroundColor = [UIColor clearColor];
    UILabel *headerLable = [[UILabel alloc]init];
    headerLable.frame = CGRectMake(10*quantityMultiply, 0, self.view.frame.size.width, 40*quantityMultiply);
    [headerLable setTextAlignment:NSTextAlignmentLeft];
    [headerLable setTextColor:[UIColor colorWithWhite:.7 alpha:1]];
    headerLable.font = [UIFont systemFontOfSize:15*quantityMultiply];
    headerLable.text = [headerList objectAtIndex:section];
    [headerView addSubview:headerLable];
    return headerView;
}
-(UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static  NSString *identifier = @"MyCell";
    SettingTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    if(cell == nil){
        cell = [[SettingTableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:identifier];
        cell.cellImage.frame = CGRectMake(10, tableView.rowHeight/2 - (15*quantityMultiply), 30*quantityMultiply, 30 *quantityMultiply);
        cell.titleLbleInfo.frame = CGRectMake(cell.cellImage.frame.size.width + 15*quantityMultiply, 0, self.view.frame.size.width , tableView.rowHeight);
        cell.titleLbleInfo.font = [UIFont systemFontOfSize:15*quantityMultiply];
        
        
        cell.mSwitch.hidden = true;
        [cell.mSwitch setFrame:CGRectMake(0, 0, 0, 0)];
        
    }
    
    if(indexPath.section == 5){
        cell.mSwitch.hidden = false;
        [cell.mSwitch setOn:[Utiity getIsBackgroundMusicsEnable]];
        [cell.mSwitch setFrame:CGRectMake(self.view.frame.size.width - 60*quantityMultiply, cell.contentView.bounds.size.height/2 - 15, 80, 30)];
        cell.titleLbleInfo.frame = CGRectMake(10*quantityMultiply, 0, self.view.frame.size.width , tableView.rowHeight);

    }else{
        cell.mSwitch.hidden = true;
        [cell.mSwitch setFrame:CGRectMake(0, 0, 0, 0)];
        cell.titleLbleInfo.frame = CGRectMake(cell.cellImage.frame.size.width + 15*quantityMultiply, 0, self.view.frame.size.width , tableView.rowHeight);

    }

    cell.backgroundColor = [UIColor clearColor];
    cell.titleLbleInfo.text = [[contentArray objectAtIndex:indexPath.section] objectAtIndex: indexPath.row];
    cell.titleLbleInfo.textColor  = [UIColor colorWithWhite:.8 alpha:1];
    cell.cellImage.image =[UIImage imageNamed:[[imageListArray objectAtIndex:indexPath.section] objectAtIndex: indexPath.row]];
    cell.backgroundColor = [UIColor clearColor];
    return cell;
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    [tableView deselectRowAtIndexPath:indexPath animated:true];
    
    if(indexPath.section == 0)
    {
        if(indexPath.row == 0)
        {
            //Recommends
            [self recommends];
        }
        else
        {
            // Rate of swift
            [self openUrlActionWithUrlStr:RATE_OF_APP];
            
        }
    }
    else if (indexPath.section == 1)
    {
        if(indexPath.row == 0)
        {
            //feedback
            [self sendMailActionBody:@"PFA" andSubject:SUBJECT_FEEDBACK];
        }
        else
        {
            // Help
            [self sendMailActionBody:@"Thanks for Support" andSubject:SUBJECT_HELP];
        }
    }
    else if (indexPath.section == 2)
    {
        if(indexPath.row == 1)
        {
            //follow us on twitter
            NSString *url = nil;
            if([[UIApplication sharedApplication] canOpenURL:[NSURL URLWithString:@"twitter://"]]){
                url = [NSString stringWithFormat:@"twitter://user?screen_name=%@",TWITTER_ACCOUNT_NAME];
            }else{
                url = FOLLOW_US_ON_TWITTER;
            }
            [self openUrlActionWithUrlStr:url];
        }
        else
        {
            //follow us on facebook
            
            NSString *url = nil;
            if([[UIApplication sharedApplication] canOpenURL:[NSURL URLWithString:@"fb://"]]){
                url = [NSString stringWithFormat:@"fb://profile/%@",FACEBOOK_ACCOUNT_NAME];
            }else{
                url = LIKE_US_ON_FACEBOOK;
            }
            [self openUrlActionWithUrlStr:url];
        }
    }
    else if (indexPath.section == 3)
    {
        if(indexPath.row == 0)
        {
            [self restoreAction];
            
        }else if(indexPath.row == 1){
            [self showPurchasePopUp];
        }else {
           
            WebViewController *webView = [[WebViewController alloc]initWithNibName:@"WebViewController" bundle:nil];
            webView.selectedIndex = indexPath.row;
            webView.titleNavi = [[contentArray objectAtIndex:indexPath.section] objectAtIndex: indexPath.row];
            [self.navigationController pushViewController:webView animated:true];
        }
    }
    else if (indexPath.section == 4)
    {
        NSString *loiosVersion = [NSString stringWithFormat:@"iOS %@",[[UIDevice currentDevice] systemVersion]];
        NSString *submiteTextWriteByUser = [[NSUserDefaults standardUserDefaults]objectForKey:@"k_submiteTextWriteByUser"];
        if(submiteTextWriteByUser.length == 0)
            submiteTextWriteByUser = @"";
        NSString  *mBody =[NSString stringWithFormat:@"%@\n\n\n\n-- The information below this line is for diagnostic purposes for our engineers to track down and resolve any issues. It doesn't contain any sensitive information, but feel free to remove it if you do not want to send it -- \n\n\n App Name: %@ \n App Version: 1.0.0 \n IOS Version: %@",submiteTextWriteByUser,APP_NAME, loiosVersion];
        [self sendMailActionBody:mBody andSubject:@"Report issue"];
        
    }
    
    
}

#pragma mark comming from setting page
-(void)openUrlActionWithUrlStr:(NSString *)url
{
    // NSString *escaped = [url stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    [[UIApplication sharedApplication] openURL:[NSURL URLWithString:url]];
}

- (void)recommends
{
    
    //I am learning a Swift Coding Programming language with 200 above example and interactive tutorials
    //@"I'm learning a Swift Coding with 210 bit- sized,interactive tutorials! and example";
    NSString *messageBody = RECOMMENDS_BODY;
    
    
    NSString *urlOfApp = RATE_OF_APP;
    UIImage *appIcon = [UIImage imageNamed:APP_IMAGE];
    NSArray *objectsToShare = @[urlOfApp,appIcon,messageBody];
    
    
    UIActivityViewController *activityVC = [[UIActivityViewController alloc] initWithActivityItems:objectsToShare applicationActivities:nil];
    [activityVC setValue:RECOMMENDS_SUBJECT forKey:@"subject"];
    NSArray *excludeActivities = @[UIActivityTypeAirDrop,
                                   UIActivityTypePrint,
                                   UIActivityTypeAssignToContact,
                                   UIActivityTypeSaveToCameraRoll,
                                   UIActivityTypeAddToReadingList,
                                   UIActivityTypePostToFlickr,UIActivityTypeCopyToPasteboard,
                                   UIActivityTypePostToVimeo];
    activityVC.excludedActivityTypes = excludeActivities;
    
    //if iPhone
    if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad) {
        UIPopoverController *popViewController = [[UIPopoverController alloc]initWithContentViewController:activityVC];
        [popViewController presentPopoverFromRect:CGRectMake(self.view.frame.size.width/2, self.view.frame.size.height/4, 0, 0) inView:self.view permittedArrowDirections:UIPopoverArrowDirectionAny animated:YES];
    } else { //if iPad
        // Change Rect to position Popover
        [self presentViewController:activityVC animated:YES completion:nil];
    }
}

//================================== Mail Composer View controller ==========================================
#pragma mark - MailAction
-(void)sendMailActionBody:(NSString*)messageBody andSubject:(NSString*)subject
{
    //mailView = [[UIView alloc] initWithFrame:CGRectMake(0, 0,self.view.frame.size.width,self.view.frame.size.height)];
    //[mailView setBackgroundColor:[UIColor clearColor]];
    Class mailClass = (NSClassFromString(@"MFMailComposeViewController"));
    if (mailClass != nil)
    {
        if ([mailClass canSendMail])
        {
            [self displayComposerSheetBody:messageBody andSubject:subject];
        }
        else
        {
            //[self launchMailAppOnDevice];
            [[[UIAlertView alloc]initWithTitle:@"Account Alert" message:@"Login Your Mail On Device" delegate:self cancelButtonTitle:@"Ok" otherButtonTitles: nil]show];
        }
    }
}
-(BOOL)prefersStatusBarHidden{
    return true;
}

-(void)displayComposerSheetBody:(NSString*)messageBody andSubject:(NSString*)subject
{
    MFMailComposeViewController  *picker = [[MFMailComposeViewController alloc] init];
    picker.mailComposeDelegate = self;
    [picker setSubject:subject];
    
    NSString *emailId = @"rk.iapptechnology@gmail.com";
    [picker setToRecipients:[NSArray arrayWithObjects:emailId, nil]];
    
    // Fill out the email body text
    [picker setMessageBody:messageBody isHTML:NO];
    [self presentViewController:picker animated:YES completion:nil];
}
- (NSString*) platformCode
{
    struct utsname systemInfo;
    uname(&systemInfo);
    NSString* platform =  [NSString stringWithCString:systemInfo.machine encoding:NSUTF8StringEncoding];
    return platform;
}
-(NSString*) platformName
{
    NSString* platform = [self platformCode];
    if ([platform isEqualToString:@"iPhone1,1"])    return @"iPhone 1G";
    
    if ([platform isEqualToString:@"iPhone1,2"])    return @"iPhone 3G";
    
    if ([platform isEqualToString:@"iPhone2,1"])    return @"iPhone 3GS";
    
    if ([platform isEqualToString:@"iPhone3,1"])    return @"iPhone 4";
    
    if ([platform isEqualToString:@"iPhone3,2"])    return @"Verizon iPhone 4";
    
    if ([platform isEqualToString:@"iPhone4,1"])    return @"iPhone 4S";
    
    if ([platform isEqualToString:@"iPod1,1"])      return @"iPod Touch 1G";
    
    if ([platform isEqualToString:@"iPod2,1"])      return @"iPod Touch 2G";
    
    if ([platform isEqualToString:@"iPod3,1"])      return @"iPod Touch 3G";
    
    if ([platform isEqualToString:@"iPod4,1"])      return @"iPod Touch 4G";
    
    if ([platform isEqualToString:@"iPad1,1"])      return @"iPad";
    
    if ([platform isEqualToString:@"iPad2,1"])      return @"iPad 2 (WiFi)";
    
    if ([platform isEqualToString:@"iPad2,2"])      return @"iPad 2 (GSM)";
    
    if ([platform isEqualToString:@"iPad2,3"])      return @"iPad 2 (CDMA)";
    
    if ([platform isEqualToString:@"i386"])         return @"Simulator";
    
    return platform;
}

- (void)mailComposeController:(MFMailComposeViewController*)controller didFinishWithResult:(MFMailComposeResult)result error:(NSError*)error
{
    switch (result)
    {
        case MFMailComposeResultCancelled:
            break;
        case MFMailComposeResultSaved:
            break;
        case MFMailComposeResultSent:
            printf("send");
            break;
        case MFMailComposeResultFailed:
            printf("failed");
            break;
        default:
            break;
    }
    isDoneMailAction = true;
    [self becomeFirstResponder];
    [self dismissViewControllerAnimated:YES completion:Nil];
}

-(void)restoreAction{
    
    if([self checkNetworkStatus])
    {
        [[MKStoreKit sharedKit] restorePurchases];
        [[DPCustomeActivity defaultAgent] makeBusy:true];
        
    }
    
}
-(void)productPurchasedSuccessfully{
    [[DPCustomeActivity defaultAgent] makeBusy:false];

}
-(void)purchaseRestoreFailedFailedNotification{
    [[DPCustomeActivity defaultAgent] makeBusy:false];
 
}

//#pragma mark - Start In app Purchase ===================================
//#pragma mark -
//
//-(void)addPurchaseNotification{
//    if(![Utiity getIsUserHasPurchasedItemFromAppStore]){
//        
//        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(productPurchased:) name:IAPHelperProductPurchasedNotification object:nil];
//        
//        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(productPurchasedFailed:) name:IAPHelperProductPurchasedFailedNotification object:nil];
//    }
//}
//
//-(void)buyProductIAP{
//    
//    if(isBuyButtoneClick == NO)
//    {
//        isBuyButtoneClick = YES;
//        _products = nil;
//        [[RageIAPHelper sharedInstance] requestProductsWithCompletionHandler:^(BOOL success, NSArray *products) {
//            if (success)
//            {
//                _products = products;
//                if(_products.count != 0)
//                {
//                    
//                    [[RageIAPHelper sharedInstance] setDelegate:self];
//                    
//                    SKProduct *product = _products[0];
//                    if(product != nil){
//                        NSLog(@"Buying %@...", product.productIdentifier);
//                        [[RageIAPHelper sharedInstance] buyProduct:product];
//                    }
//                }else{
//                    isBuyButtoneClick = NO;
//                    NSLog(@"peoduct is nill");
//                }
//            }else{
//                isBuyButtoneClick = NO;
//                NSLog(@"getting error to downlod product");
//                
//            }
//            
//        }];
//    }
//}
//#pragma mark - Purchase and failed delegate methode
//- (void)productPurchased:(NSNotification *)notification {
//    NSLog(@"productPurchased successfullly");
//    NSString * productIdentifier = notification.object;
//    [_products enumerateObjectsUsingBlock:^(SKProduct * product, NSUInteger idx, BOOL *stop) {
//        if ([product.productIdentifier isEqualToString:productIdentifier]) {
//            *stop = YES;
//            isBuyButtoneClick = NO;
//            [Utiity setIsUserHasPurchasedItemFromAppStore:YES];
//            [self show_Hide_FrameView];
//            AppDelegate *delegate = (AppDelegate*)[UIApplication sharedApplication].delegate;
//            [delegate setHiddenWithModView];
//            
//            
//        }
//    }];
//}
//- (void)productPurchasedFailed:(NSError*)error{
//    
//    NSLog(@"product Purchasing failed");
//    isBuyButtoneClick = NO;
//    
//}
//- (void)BuyProductAction:(id)sender {
//    
//    if(![self checkNetworkStatus]){
//        [self buyProductIAP];
//    };
//}
//
-(BOOL)isReachble {
    ReachablityCustome *reachable = [[ReachablityCustome alloc]init];
    if ([reachable isInternetConnectionReachable] == true){
        return true;
    }else{
        return false;
        
    }
}
-(NSInteger)checkNetworkStatus
{
    if ([self isReachble] == true)
    {
        return 1;
    }
    else
    {
        
        NSString  *malert1=@"Network Status";
        NSString  *malert2=@"Please check your Internet connection and try again.";
        [[[UIAlertView alloc]initWithTitle:malert1 message:malert2 delegate:self cancelButtonTitle:@"Ok" otherButtonTitles:nil, nil]show];
        return 0;
    }
}
- (void)dealloc{
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}



//#pragma mark - End In app Purchase ===================================
//#pragma mark -
//
//
//#pragma mark  In app purchase -------------------------------
//#pragma mark - Purchase and failed delegate methode
//
//- (void)resotoreRequestIAP
//{
//    if(![self checkNetworkStatus]){
//        [[RageIAPHelper sharedInstance] setDelegate:self];
//        [[RageIAPHelper sharedInstance] restoreCompletedTransactions];
//    };
//}
//
//-(void) successfulPurchase:(IAPHelper*)ebp restored:(bool)isRestore identifier:(NSString*)productId receipt:(NSData*)transactionReceipt
//{
//    NSLog(@"ViewController successfulPurchase");
//    
//    // Purchase or Restore request was successful, so...
//    // 1 - Unlock the purchased content for your new customer!
//    // 2 - Notify the user that the transaction was successful.
//    
//    if (!isPurchased)
//    {
//        // If paid status has not yet changed, then do so now. Checking
//        // isPurchased boolean ensures user is only shown Thank You message
//        // once even if multiple transaction receipts are successfully
//        // processed (such as past subscription renewals).
//        
//        isPurchased = YES;
//        [Utiity setIsUserHasPurchasedItemFromAppStore:YES];
//        [self show_Hide_FrameView];
//        AppDelegate *delegate = (AppDelegate*)[UIApplication sharedApplication].delegate;
//        [delegate setHiddenWithModView];
//        
//    }
//}
//-(void) incompleteRestore:(IAPHelper*)ebp
//{
//    NSLog(@"ViewController incompleteRestore");
//    
//    // Restore queue did not include any transactions, so either the user has not yet made a purchase
//    // or the user's prior purchase is unavailable, so notify user to make a purchase within the app.
//    // If the user previously purchased the item, they will NOT be re-charged again, but it should
//    // restore their purchase.
//}
//-(void) failedRestore:(IAPHelper*)ebp error:(NSInteger)errorCode message:(NSString*)errorMessage
//{
//    NSLog(@"ViewController failedRestore");
//    
//}

#pragma mark- End inAppPurchasing ***************************************************

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
@end

@implementation SettingTableViewCell

-(id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if(self)
    {
        //NSLog(@"Rect == %@",NSStringFromCGRect(self.frame));
        
        self.cellImage = [[UIImageView alloc]init];
        self.cellImage.backgroundColor = [UIColor clearColor];
        [self addSubview:self.cellImage];
        
        _mSwitch = [[UISwitch alloc]initWithFrame:CGRectMake(0, 10, 100, 30)];
        [self addSubview:_mSwitch];
        [_mSwitch addTarget:self action:@selector(backGroundMusics:) forControlEvents:UIControlEventValueChanged];

        
        
        self.titleLbleInfo = [[UILabel alloc]init];
        self.titleLbleInfo.backgroundColor = [UIColor clearColor];
        self.titleLbleInfo.textColor = [UIColor blackColor];
        [self addSubview:self.titleLbleInfo];
    }
    return self;
}
-(void)backGroundMusics:(id)sender{
    UISwitch *switchBar = (UISwitch*)sender;
    [Utiity setgetIsBackgroundMusicsEnable:switchBar.isOn];
    if(switchBar.isOn){
        [[Utiity sharedInstance] playBackgroungAudio];
    }else{
        [[Utiity sharedInstance] stopPlayBckgroundMusicActionByUser];
    }
}

@end
